#include <math.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "element_definitions.h"
#include "global_defs.h"
#include "mpi.h"
#include <stdlib.h>


void calculate_melting_flux(E)
	struct All_variables *E;
{
terminate();
return;
} 
