/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *<LicenseText>
 *
 * CitcomS by Louis Moresi, Shijie Zhong, Lijie Han, Eh Tan,
 * Clint Conrad, Michael Gurnis, and Eun-seo Choi.
 * Copyright (C) 1994-2005, California Institute of Technology.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *</LicenseText>
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
/* Routine to process the output of the finite element cycles
   and to turn them into a coherent suite  files  */
#include <fcntl.h>

#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <mpi.h>
#include "element_definitions.h"
#include "global_defs.h"
#include "parsing.h"
#include "output.h"

void binary_output_temp();
void binary_output_stress();
void binary_output_tracer();
void binary_output_pressure();
void binary_output_strain_rate();
void binary_output_ppv();
void binary_output_visc();
void binary_output_comp();
void binary_output_velo();
void output_comp_nd_bin(struct All_variables *, int);//nanzhang 2009
void output_comp_nd(struct All_variables *, int);
void output_comp_el(struct All_variables *, int);
void output_coord(struct All_variables *);
void output_mat(struct All_variables *);
void output_velo(struct All_variables *, int);
void output_velo_bin(struct All_variables *, int);//nanzhang 2009
void output_visc_prepare(struct All_variables *, float **);
void output_visc(struct All_variables *, int);
void output_surf_botm(struct All_variables *, int);
void output_geoid(struct All_variables *, int);
void output_stress(struct All_variables *, int);
void output_horiz_avg(struct All_variables *, int);
void output_tracer(struct All_variables *, int);
void output_pressure(struct All_variables *, int);
void output_heating(struct All_variables *, int);
extern void parallel_process_termination();
extern void heat_flux(struct All_variables *);
extern void get_STD_topo(struct All_variables *, float**, float**,
                         float**, float**, int);
extern void get_CBF_topo(struct All_variables *, float**, float**);
extern void CBF_heat_flux(struct All_variables *,double **,double **,struct SOURCES *,int, unsigned int **);//nanzhang 2009
/**********************************************************************/

void output_common_input(struct All_variables *E)
{
    int m = E->parallel.me;

    input_string("output_format", E->output.format, "ascii",m);
    input_string("output_format_TC", E->output.format_TC, "ascii",m);//nanzhang Nov.2009
    input_string("output_optional", E->output.optional, "surf,botm,tracer",m);

    /* gzdir type of I/O */
    E->output.gzdir.vtk_io = 0;
    E->output.gzdir.rnr = 0;
    if(strcmp(E->output.format, "ascii-gz") == 0){
      /*
	 vtk_io = 1: write files for post-processing into VTK
	 vtk_io = 2: write serial legacy VTK file
	 vtk_io = 3: write paralle legacy VTK file

      */
      input_int("gzdir_vtkio",&(E->output.gzdir.vtk_io),"0",m);
      /* remove net rotation on output step? */
      input_boolean("gzdir_rnr",&(E->output.gzdir.rnr),"off",m);
      E->output.gzdir.vtk_base_init = 0;
      E->output.gzdir.vtk_base_save = 1; /* should we save the basis vectors? (memory!) */
      //fprintf(stderr,"gzdir: vtkio: %i save basis vectors: %i\n",
      //      E->output.gzdir.vtk_io,E->output.gzdir.vtk_base_save);
    }
}



void output(struct All_variables *E, int cycles)
{
   
  if (cycles == 0) {
    output_coord(E);
    output_domain(E);
    /*output_mat(E);*/
    if (E->output.coord_bin)
        output_coord_bin(E);
  }

  if (strcmp(E->output.format_TC, "bin") == 0) {
    output_velo_bin(E, cycles);//nanzhang Nov.2009
  }
  else {  output_velo(E, cycles);
  }
  //output_visc(E, cycles);

  output_surf_botm(E, cycles);

  /* optional output below */

  /* compute and output geoid (in spherical harmonics coeff) */
  if (E->output.geoid)		/* this needs to be called after the
				   surface and bottom topo has been
				   computed! */
      output_geoid(E, cycles);

  if (E->output.stress){
       output_stress(E, cycles);
  }
  if (E->output.pressure)
    output_pressure(E, cycles);

  if (E->output.horiz_avg)
      output_horiz_avg(E, cycles);

  if (E->output.seismic)
      output_seismic(E, cycles);

  if(E->output.tracer && E->control.tracer) {
      if((E->monitor.solution_cycles % 5000)==0)
         output_tracer(E, cycles);
  }

  if (E->output.comp_nd && E->composition.on) {
     if(strcmp(E->output.format_TC, "bin") == 0) {
        output_comp_nd_bin(E, cycles);//nanzhang 2009
     }
     else  output_comp_nd(E, cycles);
  }
  if (E->output.comp_el && E->composition.on)
      output_comp_el(E, cycles);

  if(E->output.heating && E->control.disptn_number != 0)
      output_heating(E, cycles);

  return;
}


FILE* output_open(char *filename, char *mode)
{
  FILE *fp1;

  /* if filename is empty, output to stderr. */
  if (*filename) {
    fp1 = fopen(filename,mode);
    if (!fp1) {
      fprintf(stderr,"Cannot open file '%s' for '%s'\n",
	      filename,mode);
      parallel_process_termination();
    }
  }
  else
    fp1 = stderr;

  return fp1;
}


void output_coord(struct All_variables *E)
{
  int i, j;
  char output_file[255];
  FILE *fp1;

  sprintf(output_file,"%s.coord.%d",E->control.data_file,E->parallel.me);
  fp1 = output_open(output_file, "w");

  for(j=1;j<=E->sphere.caps_per_proc;j++)     {
    fprintf(fp1,"%3d %7d\n",j,E->lmesh.nno);
    for(i=1;i<=E->lmesh.nno;i++)
      fprintf(fp1,"%.6e %.6e %.6e\n",E->sx[j][1][i],E->sx[j][2][i],E->sx[j][3][i]);
  }

  fclose(fp1);

  return;
}


void output_domain(struct All_variables *E)
{
    /* This routine outputs the domain bounds in a single file. */
    /* The file will be useful for external program to understand */
    /* how the CitcomS mesh is domain decomposed. */

    /* Note: rank-0 writes the domain bounds of all processors */

    const int j = 1;
    const int tag = 0;
    const int receiver = 0;
    const int nox = E->lmesh.nox;
    const int noy = E->lmesh.noy;
    const int noz = E->lmesh.noz;
    const int corner_nodes[4] = {1,
                                 1 + noz*(nox-1),
                                 nox*noy*noz - (noz -1),
                                 1 + noz*nox*(noy-1)};
    /* Each line has so many columns:
     * The columns are min(r) and max(r),
     * then (theta, phi) of 4 bottom corners. */
#define ncolumns 10

    double buffer[ncolumns];

    buffer[0] = E->sx[j][3][1];
    buffer[1] = E->sx[j][3][noz];
    buffer[2] = E->sx[j][1][corner_nodes[0]];
    buffer[3] = E->sx[j][2][corner_nodes[0]];
    buffer[4] = E->sx[j][1][corner_nodes[1]];
    buffer[5] = E->sx[j][2][corner_nodes[1]];
    buffer[6] = E->sx[j][1][corner_nodes[2]];
    buffer[7] = E->sx[j][2][corner_nodes[2]];
    buffer[8] = E->sx[j][1][corner_nodes[3]];
    buffer[9] = E->sx[j][2][corner_nodes[3]];

    if(E->parallel.me == 0) {
        int i, rank;
        char output_file[255];
        FILE *fp1;
        int32_t header[4];
        MPI_Status status;

        sprintf(output_file,"%s.domain",E->control.data_file);
        fp1 = output_open(output_file, "wb");

        /* header */
        header[0] = E->parallel.nproc;
        header[1] = ncolumns;
        header[2] = 0x12345678;  /* guard */
        header[3] = sizeof(int32_t);
        fwrite(header, sizeof(int32_t), 4, fp1);

        /* bounds of self */
        fwrite(buffer, sizeof(double), ncolumns, fp1);

        /* bounds of other processors */
        for(rank=1; rank<E->parallel.nproc; rank++) {
            MPI_Recv(buffer, ncolumns, MPI_DOUBLE, rank, tag, E->parallel.world, &status);
            fwrite(buffer, sizeof(double), ncolumns, fp1);
        }

        fclose(fp1);
    }
    else {
        MPI_Send(buffer, ncolumns, MPI_DOUBLE, receiver, tag, E->parallel.world);
    }

#undef ncolumns

    return;
}


/* write coordinates in binary double */
void output_coord_bin(struct All_variables *E)
{
  int i, j;
  char output_file[255];
  FILE *fp1;

  sprintf(output_file,"%s.coord_bin.%d",E->control.data_file,E->parallel.me);
  fp1 = output_open(output_file, "wb");

  for(j=1;j<=E->sphere.caps_per_proc;j++) {
      int32_t header[4];
      header[0] = E->lmesh.nox;
      header[1] = E->lmesh.noy;
      header[2] = E->lmesh.noz;
      header[3] = 0x12345678; /* guard */
      fwrite(header, sizeof(int32_t), 4, fp1);

      fwrite(&(E->x[j][1][1]), sizeof(double), E->lmesh.nno, fp1);
      fwrite(&(E->x[j][2][1]), sizeof(double), E->lmesh.nno, fp1);
      fwrite(&(E->x[j][3][1]), sizeof(double), E->lmesh.nno, fp1);
  }

  fclose(fp1);

  return;
}


void output_visc(struct All_variables *E, int cycles)
{
  int i, j;
  char output_file[255];
  FILE *fp1;
  int lev = E->mesh.levmax;

  sprintf(output_file,"%s.visc.%d.%d", E->control.data_file,
          E->parallel.me, cycles);
  fp1 = output_open(output_file, "w");


  for(j=1;j<=E->sphere.caps_per_proc;j++) {
    fprintf(fp1,"%3d %7d\n",j,E->lmesh.nno);
    for(i=1;i<=E->lmesh.nno;i++)
      fprintf(fp1,"%.4e\n",E->VI[lev][j][i]);
  }

  fclose(fp1);

  return;
}


void output_velo(struct All_variables *E, int cycles)
{
  int i, j;
  char output_file[255];
  FILE *fp1;

  sprintf(output_file,"%s.velo.%d.%d", E->control.data_file,
          E->parallel.me, cycles);
  fp1 = output_open(output_file, "w");

  fprintf(fp1,"%d %d %.5e\n",cycles,E->lmesh.nno,E->monitor.elapsed_time);

  for(j=1;j<=E->sphere.caps_per_proc;j++) {
    fprintf(fp1,"%3d %7d\n",j,E->lmesh.nno);
    for(i=1;i<=E->lmesh.nno;i++) {
        fprintf(fp1,"%.6e %.6e %.6e %.6e\n",E->sphere.cap[j].V[1][i],E->sphere.cap[j].V[2][i],E->sphere.cap[j].V[3][i],E->T[j][i]);
       //fprintf(fp1,"%.6e %.6e\n",E->T[j][i],E->sphere.cap[j].V[3][i]);
       //fprintf(fp1,"%.6e\n",E->T[j][i]);
    }
  }

  fclose(fp1);

  return;
}

void output_velo_bin(struct All_variables *E, int cycles)//nanzhang Nov.2009
{
  int i,j,size1;
  float *SV,*VV;
  char output_file[255];
  FILE *fp1;

  SV = (float *) malloc ((E->lmesh.nno+1)*sizeof(float));
  VV = (float *) malloc ((E->lmesh.nno+1)*sizeof(float));
  sprintf(output_file,"%s.flux.%d.%d",E->control.data_file,E->parallel.me,cycles);
  if(cycles%400==0) {
      fp1 = output_open(output_file, "w");
      for(j=1;j<=E->sphere.caps_per_proc;j++) {
         fprintf(fp1,"%3d %7d\n",j,E->lmesh.nno);
         for(i=1;i<=E->lmesh.nno;i++) {
             fprintf(fp1,"%.6e\n",E->flux[j][i]);
         }
      }
  }
  close(fp1);

  sprintf(output_file,"%s.velo_bin.%d.%d",E->control.data_file,E->parallel.me,cycles);
  if(cycles%5000==0) {
      fp1 = output_open(output_file, "w");
      fprintf(fp1,"%d %d %.5e\n",cycles,E->lmesh.nno,E->monitor.elapsed_time);
      for(j=1;j<=E->sphere.caps_per_proc;j++) {
         fprintf(fp1,"%3d %7d\n",j,E->lmesh.nno);
         for(i=1;i<=E->lmesh.nno;i++) {
             fprintf(fp1,"%.6e %.6e %.6e %.6e\n",E->sphere.cap[j].V[1][i],E->sphere.cap[j].V[2][i],E->sphere.cap[j].V[3][i],E->T[j][i]);      
         }
      }//j over      
  }
  else {
      size1 = (E->lmesh.nno + 1) * sizeof(float);
      fp1=open(output_file,O_RDWR | O_CREAT, 0644);
      write(fp1,&(cycles),sizeof(int));
      write(fp1,&(E->lmesh.nno),sizeof(int));
      write(fp1,&(E->monitor.elapsed_time),sizeof(float));
      for(j=1;j<=E->sphere.caps_per_proc;j++)     {
         for(i=1;i<=E->lmesh.nno;i++) {
            SV[i]=E->T[j][i];
            VV[i]=E->sphere.cap[j].V[3][i];
         }
         write(fp1,SV,size1);
         //write(fp1,VV,size1);
      }
   }
   free((void *) SV);
   free((void *) VV);
   close(fp1);
} 

void output_surf_botm(struct All_variables *E, int cycles)
{
  int i, j, s;
  char output_file[255];
  FILE* fp2;
  float *topo;

  //if((E->output.write_q_files == 0) || (cycles == 0) ||
  //   (cycles % E->output.write_q_files)!=0)
      //heat_flux(E);      
  /* else, the heat flux will have been computed already */

  if(E->control.use_cbf_topo){
    get_CBF_topo(E,E->slice.tpg,E->slice.tpgb);

  }else{
    get_STD_topo(E,E->slice.tpg,E->slice.tpgb,E->slice.divg,E->slice.vort,cycles);
  }

  if (E->output.surf && (E->parallel.me_loc[3]==E->parallel.nprocz-1)) {

    sprintf(output_file,"%s/%d/surf.%d.%d", E->control.data_dir,cycles,
            E->parallel.me, cycles);
    fp2 = output_open(output_file, "w");

    for(j=1;j<=E->sphere.caps_per_proc;j++)  {
        /* choose either STD topo or pseudo-free-surf topo */
        if(E->control.pseudo_free_surf)
            topo = E->slice.freesurf[j];
        else
            topo = E->slice.tpg[j];

        fprintf(fp2,"%3d %7d\n",j,E->lmesh.nsf);
        for(i=1;i<=E->lmesh.nsf;i++)   {
            s = i*E->lmesh.noz;
            fprintf(fp2,"%.4e %.4e %.4e %.4e %.4e\n",
		    topo[i],E->slice.shflux[j][i],E->slice.shflux_CBF[j][i],E->sphere.cap[j].V[1][s],E->sphere.cap[j].V[2][s]);
        }
    }
    fclose(fp2);
  }


  if (E->output.botm && (E->parallel.me_loc[3]==0)) {
    sprintf(output_file,"%s/%d/botm.%d.%d", E->control.data_dir,cycles,
            E->parallel.me, cycles);
    fp2 = output_open(output_file, "w");

    for(j=1;j<=E->sphere.caps_per_proc;j++)  {
      fprintf(fp2,"%3d %7d\n",j,E->lmesh.nsf);
      for(i=1;i<=E->lmesh.nsf;i++)  {
        s = (i-1)*E->lmesh.noz + 1;
        fprintf(fp2,"%.4e %.4e %.4e %.4e %.4e %.4e\n",
		E->slice.tpgb[j][i],E->slice.bhflux[j][i],E->slice.bhflux_CBF[j][i],E->sphere.cap[j].V[1][s],E->sphere.cap[j].V[2][s],E->Fascmb_b[j][i]);//Fascmb_b
      }
    }
    fclose(fp2);
  }

  return;
}


void output_geoid(struct All_variables *E, int cycles)
{
    void compute_geoid();
    int ll, mm, p;
    char output_file[255];
    FILE *fp1;

    compute_geoid(E);

    if (E->parallel.me == (E->parallel.nprocz-1))  {
        sprintf(output_file,"%s/%d/geoid.%d.%d", E->control.data_dir,cycles,
                E->parallel.me, cycles);
        fp1 = output_open(output_file, "w");

        /* write headers */
        fprintf(fp1, "%d %d %.5e\n", cycles, E->output.llmax,
                E->monitor.elapsed_time);

        /* write sph harm coeff of geoid and topos */
        for (ll=0; ll<=E->output.llmax; ll++)
            for(mm=0; mm<=ll; mm++)  {
                p = E->sphere.hindex[ll][mm];
                fprintf(fp1,"%d %d %.4e %.4e %.4e %.4e %.4e %.4e\n",
                        ll, mm,
                        E->sphere.harm_geoid[0][p],
                        E->sphere.harm_geoid[1][p],
                        E->sphere.harm_geoid_from_tpgt[0][p],
                        E->sphere.harm_geoid_from_tpgt[1][p],
                        E->sphere.harm_geoid_from_bncy[0][p],
                        E->sphere.harm_geoid_from_bncy[1][p]);

                       
            }

        fclose(fp1);
    }
}



void output_stress(struct All_variables *E, int cycles)
{
  int m, node;
  char output_file[255];
  FILE *fp1;
 /* for stress computation */
  void allocate_STD_mem();
  void compute_nodal_stress();
  void free_STD_mem();
  float *SXX[NCS],*SYY[NCS],*SXY[NCS],*SXZ[NCS],*SZY[NCS],*SZZ[NCS];
  float *divv[NCS],*vorv[NCS];
  /*  */
  if(E->control.use_cbf_topo)	{/* for CBF topo, stress will not have been computed */
    allocate_STD_mem(E, SXX, SYY, SZZ, SXY, SXZ, SZY, divv, vorv);
    compute_nodal_stress(E, SXX, SYY, SZZ, SXY, SXZ, SZY, divv, vorv);
    free_STD_mem(E, SXX, SYY, SZZ, SXY, SXZ, SZY, divv, vorv);
  }
  sprintf(output_file,"%s.stress.%d.%d", E->control.data_file,
          E->parallel.me, cycles);
  fp1 = output_open(output_file, "w");

  fprintf(fp1,"%d %d %.5e\n",cycles,E->lmesh.nno,E->monitor.elapsed_time);

  for(m=1;m<=E->sphere.caps_per_proc;m++) {
    fprintf(fp1,"%3d %7d\n",m,E->lmesh.nno);
    /* those are sorted like stt spp srr stp str srp  */
    for (node=1;node<=E->lmesh.nno;node++)
      fprintf(fp1, "%.4e %.4e %.4e %.4e %.4e %.4e\n",
              E->gstress[m][(node-1)*6+1],
              E->gstress[m][(node-1)*6+2],
              E->gstress[m][(node-1)*6+3],
              E->gstress[m][(node-1)*6+4],
              E->gstress[m][(node-1)*6+5],
              E->gstress[m][(node-1)*6+6]);
  }
  fclose(fp1);
}


void output_horiz_avg(struct All_variables *E, int cycles)
{
  /* horizontal average output of temperature, composition and rms velocity*/
  void compute_horiz_avg();

  int j;
  char output_file[255];
  FILE *fp1;

  /* compute horizontal average here.... */
  compute_horiz_avg(E);

  /* only the first nprocz processors need to output */

  if (E->parallel.me<E->parallel.nprocz)  {
    sprintf(output_file,"%s.horiz_avg.%d.%d", E->control.data_file,
            E->parallel.me, cycles);
    fp1=fopen(output_file,"w");
    for(j=1;j<=E->lmesh.noz;j++)  {
        fprintf(fp1,"%.4e %.4e %.4e %.4e %.4e %.4e",E->sx[1][3][j],
		E->Have.T[j],E->Have.V[1][j],E->Have.V[2][j],E->Have.VI[j],E->Have.flux[j]);//nanzhang 2009

        if (E->composition.on) {
            int n;
            for(n=0; n<E->composition.ncomp; n++)
                fprintf(fp1," %.4e", E->Have.C[n][j]);
        }
        fprintf(fp1,"\n");
    }
    fclose(fp1);
  }

  return;
}



void output_seismic(struct All_variables *E, int cycles)
{
    void get_prem(double, double*, double*, double*);
    void compute_seismic_model(const struct All_variables*, double*, double*, double*);

    char output_file[255];
    FILE* fp;
    int i;

    double *rho, *vp, *vs;
    const int len = E->lmesh.nno;

    rho = malloc(len * sizeof(double));
    vp = malloc(len * sizeof(double));
    vs = malloc(len * sizeof(double));
    if(rho==NULL || vp==NULL || vs==NULL) {
        fprintf(stderr, "Error while allocating memory\n");
        abort();
    }

    /* isotropic seismic velocity only */
    /* XXX: update for anisotropy in the future */
    compute_seismic_model(E, rho, vp, vs);

    sprintf(output_file,"%s.seismic.%d.%d", E->control.data_file, E->parallel.me, cycles);
    fp = output_open(output_file, "wb");

    fwrite(rho, sizeof(double), E->lmesh.nno, fp);
    fwrite(vp, sizeof(double), E->lmesh.nno, fp);
    fwrite(vs, sizeof(double), E->lmesh.nno, fp);

    fclose(fp);

#if 0
    /** debug **/
    sprintf(output_file,"%s.dv.%d.%d", E->control.data_file, E->parallel.me, cycles);
    fp = output_open(output_file, "w");
    fprintf(fp, "%d %d %.5e\n", cycles, E->lmesh.nno, E->monitor.elapsed_time);
    for(i=0; i<E->lmesh.nno; i++) {
        double vpr, vsr, rhor;
        int nz = (i % E->lmesh.noz) + 1;
        get_prem(E->sx[1][3][nz], &vpr, &vsr, &rhor);

        fprintf(fp, "%.4e %.4e %.4e\n",
                rho[i]/rhor - 1.0,
                vp[i]/vpr - 1.0,
                vs[i]/vsr - 1.0);

    }
    fclose(fp);
#endif

    free(rho);
    free(vp);
    free(vs);
    return;
}


void output_mat(struct All_variables *E)
{
  int m, el;
  char output_file[255];
  FILE* fp;

  sprintf(output_file,"%s.mat.%d", E->control.data_file,E->parallel.me);
  fp = output_open(output_file, "w");

  for (m=1;m<=E->sphere.caps_per_proc;m++)
    for(el=1;el<=E->lmesh.nel;el++)
      fprintf(fp,"%d %d %f\n", el,E->mat[m][el],E->VIP[m][el]);

  fclose(fp);

  return;
}



void output_pressure(struct All_variables *E, int cycles)
{
  int i, j;
  char output_file[255];
  FILE *fp1;

  sprintf(output_file,"%s.pressure.%d.%d", E->control.data_file,
          E->parallel.me, cycles);
  fp1 = output_open(output_file, "w");

  fprintf(fp1,"%d %d %.5e\n",cycles,E->lmesh.nno,E->monitor.elapsed_time);

  for(j=1;j<=E->sphere.caps_per_proc;j++) {
    fprintf(fp1,"%3d %7d\n",j,E->lmesh.nno);
    for(i=1;i<=E->lmesh.nno;i++)
      fprintf(fp1,"%.6e\n",E->NP[j][i]);
  }

  fclose(fp1);

  return;
}



void output_tracer(struct All_variables *E, int cycles)
{
  int i, j, n, ncolumns;
  char output_file[255];
  FILE *fp1;

  sprintf(output_file,"%s.tracer.%d.%d", E->control.data_file,
          E->parallel.me, cycles);
  fp1 = output_open(output_file, "w");

  ncolumns = 3 + E->trace.number_of_extra_quantities;

  for(j=1;j<=E->sphere.caps_per_proc;j++) {
      fprintf(fp1,"%d %d %d %.5e\n", cycles, E->trace.ntracers[j],
              ncolumns, E->monitor.elapsed_time);

      for(n=1;n<=E->trace.ntracers[j];n++) {
          /* write basic quantities (coordinate) */
          fprintf(fp1,"%.12e %.12e %.12e",
                  E->trace.basicq[j][0][n],
                  E->trace.basicq[j][1][n],
                  E->trace.basicq[j][2][n]);

          /* write extra quantities */
          for (i=0; i<E->trace.number_of_extra_quantities; i++) {
              fprintf(fp1," %.12e", E->trace.extraq[j][i][n]);
          }
          fprintf(fp1, "\n");
      }

  }

  fclose(fp1);
  return;
}


void output_comp_nd(struct All_variables *E, int cycles)
{
    int i, j, k;
    char output_file[255],output_file2[255];
    FILE *fp1,*fp2;

    sprintf(output_file,"%s.comp_nd.%d.%d", E->control.data_file,
            E->parallel.me, cycles);
    fp1 = output_open(output_file, "w");
    sprintf(output_file2,"%s.age_snd.%d.%d", E->control.data_file,
            E->parallel.me, cycles);
    fp2 = output_open(output_file2, "w");

    for(j=1;j<=E->sphere.caps_per_proc;j++) {
        fprintf(fp1,"%3d %7d %.5e %d\n",
                j, E->lmesh.nel,
                E->monitor.elapsed_time, E->composition.ncomp);
        for(i=0;i<E->composition.ncomp;i++) {
            fprintf(fp1,"%.5e %.5e ",
                    E->composition.initial_bulk_composition[i],
                    E->composition.bulk_composition[i]);
        }
        fprintf(fp1,"\n");

        for(i=1;i<=E->lmesh.nno;i++) {
            for(k=0;k<E->composition.ncomp;k++) {
                fprintf(fp1,"%.8e ",E->composition.comp_node[j][k][i]);
            }
            fprintf(fp1,"\n");
            
            if(E->parallel.me_loc[3]==E->parallel.nprocz-1) {
               if(i%E->lmesh.noz==0) fprintf(fp2,"%.8e\n",E->trace.age_node[j][i]);
            }
        }

    }

    fclose(fp1);
    fclose(fp2);
    return;
}

void output_comp_nd_bin(struct All_variables *E, int cycles)
{
  int i, j, k,size1;
  char output_file1[255];
  FILE *fp1;

 sprintf(output_file1,"%s.comp_nd_bin.%d.%d",E->control.data_file,E->parallel.me,cycles);
 fp1=open(output_file1,O_RDWR | O_CREAT, 0644);

 size1 = (E->lmesh.nno + 1) * sizeof(double);
 write(fp1,&(cycles),sizeof(int));
 write(fp1,&E->lmesh.nno,sizeof(int));
 write(fp1,&E->monitor.elapsed_time,sizeof(float));
 write(fp1,&E->composition.initial_bulk_composition[0],sizeof(double));
 write(fp1,&E->composition.bulk_composition[0],sizeof(double));

 for(j=1;j<=E->sphere.caps_per_proc;j++) {
     for(k=0;k<E->composition.ncomp;k++) {
         write(fp1,E->composition.comp_node[j][k],size1);
       }
 }
    close(fp1);

}

void output_comp_el(struct All_variables *E, int cycles)
{
    int i, j, k;
    char output_file[255];
    FILE *fp1;

    sprintf(output_file,"%s.comp_el.%d.%d", E->control.data_file,
            E->parallel.me, cycles);
    fp1 = output_open(output_file, "w");

    for(j=1;j<=E->sphere.caps_per_proc;j++) {
        fprintf(fp1,"%3d %7d %.5e %d\n",
                j, E->lmesh.nel,
                E->monitor.elapsed_time, E->composition.ncomp);
        for(i=0;i<E->composition.ncomp;i++) {
            fprintf(fp1,"%.5e %.5e ",
                    E->composition.initial_bulk_composition[i],
                    E->composition.bulk_composition[i]);
        }
        fprintf(fp1,"\n");

        for(i=1;i<=E->lmesh.nel;i++) {
            for(k=0;k<E->composition.ncomp;k++) {
                fprintf(fp1,"%.6e ",
			E->composition.comp_el[j][k][i]);
            }
            fprintf(fp1,"\n");
        }
    }

    fclose(fp1);
    return;
}


void output_heating(struct All_variables *E, int cycles)
{
    int j, e;
    char output_file[255];
    FILE *fp1;

    sprintf(output_file,"%s.heating.%d.%d", E->control.data_file,
            E->parallel.me, cycles);
    fp1 = output_open(output_file, "w");

    fprintf(fp1,"%.5e\n",E->monitor.elapsed_time);

    for(j=1;j<=E->sphere.caps_per_proc;j++) {
        fprintf(fp1,"%3d %7d\n", j, E->lmesh.nel);
        for(e=1; e<=E->lmesh.nel; e++)
            fprintf(fp1, "%.4e %.4e %.4e\n", E->heating_adi[j][e],
                    E->heating_visc[j][e], E->heating_latent[j][e]);
    }
    fclose(fp1);

    return;
}


void output_time(struct All_variables *E, int cycles)
{
  double CPU_time0();

  double current_time = CPU_time0();

  if (E->parallel.me == 0) {
    fprintf(E->fptime,"%d %.4e %.4e %.4e %.4e\n",
            cycles,
            E->monitor.elapsed_time,
            E->advection.timestep,
            current_time - E->monitor.cpu_time_at_start,
            current_time - E->monitor.cpu_time_at_last_cycle);

    fflush(E->fptime);
  }

  E->monitor.cpu_time_at_last_cycle = current_time;

  return;
}



void binary_output(struct All_variables *E, int out_cycles)
{
char output_dir[255];
if (out_cycles == 0 )
{
	output_coord(E);
	output_domain(E);
}
snprintf(output_dir,255,"%s/%d",E->control.data_dir,out_cycles);
mkdatadir(output_dir);

binary_output_temp(E, out_cycles);
if (E->control.Ra_cmb != 0.0)
	binary_output_ppv(E, out_cycles);
binary_output_visc(E, out_cycles);
if (E->output.comp_nd && E->composition.on)
{
	binary_output_comp(E, out_cycles);
}

binary_output_velo(E, out_cycles);
output_surf_botm(E, out_cycles);
output_geoid(E, out_cycles);
output_horiz_avg(E, out_cycles);
if(E->output.stress)
{
	binary_output_stress(E,out_cycles);
}
if(E->output.pressure)
{
	binary_output_pressure(E,out_cycles);
}
if(E->output.strain_rate)
{
	binary_output_strain_rate(E,out_cycles);
}

if(E->output.tracer)
{
	binary_output_tracer(E,out_cycles);
}

return;
}


void binary_output_strain_rate(E,timestep)
	struct All_variables *E;
	int timestep;
{
int nno,nel;
FILE *fp;
char outputfile[256];
int m=1;
float *strain_rate[NCS];
float *SE;
double *P[NCS];
int i;



nno=E->lmesh.nno;
nel=E->lmesh.nel;


strain_rate[1]=malloc((nno+1)*sizeof(float));

SE=malloc((nel+2)*sizeof(float));

P[1]=malloc((nel+1)*sizeof(double));

strain_rate_2_inv(E,1,SE,1);

for(i=1;i<=E->lmesh.nel;i++)
{
        P[1][i]=SE[i];
}

p_to_nodes(E,P,strain_rate,E->mesh.levmax);
sprintf(outputfile,"%s/%d/strain_rate.%d.%d",E->control.data_dir,timestep,E->parallel.me,timestep);
fp=fopen(outputfile,"wb");
fwrite(strain_rate[1],sizeof(float),nno+1,fp);
fclose(fp);
free(strain_rate[1]);
free(SE);
free(P[1]);
return;
}


void binary_output_ppv(E,timestep)
	struct All_variables *E;
	int timestep;
{
int nno;
FILE *fp;
char outputfile[256];
int m=1;
float *ppv;
int i;

nno=E->lmesh.nno;
ppv=malloc((nno+1)*sizeof(float));
for(i=1;i<=nno;i++)
	ppv[i]=E->Fascmb[m][i];

sprintf(outputfile,"%s/%d/ppv.%d.%d",E->control.data_dir,timestep,E->parallel.me,timestep);
fp=fopen(outputfile,"wb");
fwrite(ppv,sizeof(float),nno+1,fp);
fclose(fp);
free(ppv);
return;
}

void binary_output_stress(E,timestep)
	struct All_variables *E;
	int timestep;
{
int m, node;                                                                  
char output_file[255];                                                        
FILE *fp;                                                                    
void allocate_STD_mem();                                                      
void compute_nodal_stress();                                                  
void free_STD_mem();                                                          
float *SXX[NCS],*SYY[NCS],*SXY[NCS],*SXZ[NCS],*SZY[NCS],*SZZ[NCS];            
float *divv[NCS],*vorv[NCS];                                                  
char outputfile[256];
int size;
if(E->control.use_cbf_topo)   
{
	/* for CBF topo, stress will not have been computed */
	allocate_STD_mem(E, SXX, SYY, SZZ, SXY, SXZ, SZY, divv, vorv);              
	compute_nodal_stress(E, SXX, SYY, SZZ, SXY, SXZ, SZY, divv, vorv);          
	free_STD_mem(E, SXX, SYY, SZZ, SXY, SXZ, SZY, divv, vorv);                  
}                                                                             

size=6*E->lmesh.nno+1;
sprintf(outputfile,"%s/%d/stress.%d.%d",E->control.data_dir,timestep,E->parallel.me,timestep);
fp=fopen(outputfile,"wb");
fwrite(E->gstress[1],sizeof(float),size,fp);
fclose(fp);
return;
}

void binary_output_pressure(E,timestep)
	struct All_variables *E;
	int timestep;
{
int nno;
FILE *fp;
char outputfile[256];
int m=1;
float *P;
int i;

nno=E->lmesh.nno;
P=malloc((nno+1)*sizeof(float));
for(i=1;i<=nno;i++)
	P[i]=E->NP[m][i];

sprintf(outputfile,"%s/%d/pressure.%d.%d",E->control.data_dir,timestep,E->parallel.me,timestep);
fp=fopen(outputfile,"wb");
fwrite(P,sizeof(float),nno+1,fp);
fclose(fp);
free(P);
return;
}

void binary_output_temp(E,timestep)
	struct All_variables *E;
	int timestep;
{
int nno;
FILE *fp;
char outputfile[256];
int m=1;
float *T;
int i;

nno=E->lmesh.nno;
T=malloc((nno+1)*sizeof(float));
for(i=1;i<=nno;i++)
	T[i]=E->T[m][i];

sprintf(outputfile,"%s/%d/temperature.%d.%d",E->control.data_dir,timestep,E->parallel.me,timestep);
fp=fopen(outputfile,"wb");
fwrite(T,sizeof(float),nno+1,fp);
fclose(fp);
free(T);
return;
}


void binary_output_visc(E,timestep)
	struct All_variables *E;
	int timestep;
{
int nno;
FILE *fp;
char outputfile[256];
int m=1;
float *Visc;
int i;
int lev = E->mesh.levmax;

nno=E->lmesh.nno;
Visc=malloc((nno+1)*sizeof(float));
for(i=1;i<=nno;i++)
	Visc[i]=E->VI[lev][m][i];

sprintf(outputfile,"%s/%d/viscosity.%d.%d",E->control.data_dir,timestep,E->parallel.me,timestep);
fp=fopen(outputfile,"wb");
fwrite(Visc,sizeof(float),nno+1,fp);
fclose(fp);
free(Visc);
return;
}

void binary_output_comp(E,timestep)
	struct All_variables *E;
	int timestep;
{
int nno;
FILE *fp;
char outputfile[256];
int m=1;
float *C;
int i;

int j;

nno=E->lmesh.nno;
C=malloc((nno+1)*sizeof(float));



for(i=1;i<=nno;i++)
{
	C[i]=0.0;
	for(j=0;j<E->composition.ncomp;j++)
	{
		C[i]+=E->composition.buoyancy_ratio[j]*E->composition.comp_node[1][j][i];
	}
}
sprintf(outputfile,"%s/%d/composition.%d.%d",E->control.data_dir,timestep,E->parallel.me,timestep);
fp=fopen(outputfile,"wb");
fwrite(C,sizeof(float),nno+1,fp);
fclose(fp);

free(C);
return;
}

void binary_output_tracer(E,cycles)
	struct All_variables *E;
	int cycles;
{
char outputfile[256];
int m=1;
FILE *fp;
int i, j, n, ncolumns;
sprintf(outputfile,"%s/%d/tracer.%d.%d",E->control.data_dir,cycles,E->parallel.me,cycles);
ncolumns = 3 + E->trace.number_of_extra_quantities;
fp=fopen(outputfile,"wb");
fwrite(&cycles,sizeof(int),1,fp);
fwrite(&E->trace.ntracers[1],sizeof(int),1,fp);
fwrite(&ncolumns,sizeof(int),1,fp);
fwrite(&E->monitor.elapsed_time,sizeof(float),1,fp);
fwrite(E->trace.basicq[1][0],sizeof(double),(E->trace.ntracers[1]+1),fp);
fwrite(E->trace.basicq[1][1],sizeof(double),(E->trace.ntracers[1]+1),fp);
fwrite(E->trace.basicq[1][2],sizeof(double),(E->trace.ntracers[1]+1),fp);
for (i=0; i<E->trace.number_of_extra_quantities; i++) 
{
	fwrite(E->trace.extraq[1][i],sizeof(double),(E->trace.ntracers[1]+1),fp);
}
fclose(fp);

return;
}


void binary_output_velo(E,timestep)
	struct All_variables *E;
	int timestep;
{
int nno;
FILE *fp;
char outputfile[256];
int m=1;
float *V1,*V2,*V3;
int i;

nno=E->lmesh.nno;
V1=malloc((nno+1)*sizeof(float));
V2=malloc((nno+1)*sizeof(float));
V3=malloc((nno+1)*sizeof(float));
for(i=1;i<=nno;i++)
{
	V1[i]=E->sphere.cap[m].V[1][i];
	V2[i]=E->sphere.cap[m].V[2][i];
	V3[i]=E->sphere.cap[m].V[3][i];
}

sprintf(outputfile,"%s/%d/velocity.%d.%d",E->control.data_dir,timestep,E->parallel.me,timestep);
fp=fopen(outputfile,"wb");
fwrite(V1,sizeof(float),nno+1,fp);
fwrite(V2,sizeof(float),nno+1,fp);
fwrite(V3,sizeof(float),nno+1,fp);
fclose(fp);

free(V1);
free(V2);
free(V3);
return;
}

