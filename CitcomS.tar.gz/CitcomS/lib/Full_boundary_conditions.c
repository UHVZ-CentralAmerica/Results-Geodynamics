/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *<LicenseText>
 *
 * CitcomS by Louis Moresi, Shijie Zhong, Lijie Han, Eh Tan,
 * Clint Conrad, Michael Gurnis, and Eun-seo Choi.
 * Copyright (C) 1994-2005, California Institute of Technology.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *</LicenseText>
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
#include "element_definitions.h"
#include "global_defs.h"
#include <math.h>

#include "lith_age.h"
#include "parsing.h"
/* ========================================== */

static void horizontal_bc();
static void velocity_apply_periodic_bcs();
static void temperature_apply_periodic_bcs();
void read_temperature_boundary_from_file(struct All_variables *);
void read_velocity_boundary_from_file(struct All_variables *);

/* ========================================== */

void full_velocity_boundary_conditions(E)
     struct All_variables *E;
{
  void velocity_imp_vert_bc();
  void velocity_apply_periodicapply_periodic_bcs();

  void apply_side_sbc();

  int j,noz,lv;

  for(lv=E->mesh.gridmax;lv>=E->mesh.gridmin;lv--)
    for (j=1;j<=E->sphere.caps_per_proc;j++)     {
      noz = E->mesh.NOZ[lv];
      if(E->mesh.topvbc == 0) {	/* free slip top */
	horizontal_bc(E,E->sphere.cap[j].VB,noz,1,0.0,VBX,0,lv,j);
	horizontal_bc(E,E->sphere.cap[j].VB,noz,3,0.0,VBZ,1,lv,j);
	horizontal_bc(E,E->sphere.cap[j].VB,noz,2,0.0,VBY,0,lv,j);
	horizontal_bc(E,E->sphere.cap[j].VB,noz,1,E->control.VBXtopval,SBX,1,lv,j);
	horizontal_bc(E,E->sphere.cap[j].VB,noz,3,0.0,SBZ,0,lv,j);
	horizontal_bc(E,E->sphere.cap[j].VB,noz,2,E->control.VBYtopval,SBY,1,lv,j);
	}
      if(E->mesh.botvbc == 0) {	/* free slip bottom */
        horizontal_bc(E,E->sphere.cap[j].VB,1,1,0.0,VBX,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,3,0.0,VBZ,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,2,0.0,VBY,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,1,E->control.VBXbotval,SBX,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,3,0.0,SBZ,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,2,E->control.VBYbotval,SBY,1,lv,j);
        }

      if(E->mesh.topvbc == 1) {	/* velocity/no slip BC */
        horizontal_bc(E,E->sphere.cap[j].VB,noz,1,E->control.VBXtopval,VBX,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,noz,3,0.0,VBZ,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,noz,2,E->control.VBYtopval,VBY,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,noz,1,0.0,SBX,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,noz,3,0.0,SBZ,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,noz,2,0.0,SBY,0,lv,j);

        if(E->control.vbcs_file){ /* this should either only be called
				     once, or the input routines need
				     to be told what to do for each
				     multigrid level and cap. it might
				     be easiest to call only once and
				     have routines deal with multigrid
				  */
	  if((lv == E->mesh.gridmin) && (j == E->sphere.caps_per_proc))
	     read_velocity_boundary_from_file(E);
	}
      }
      else if(E->mesh.topvbc == 2) {	/* velocity/no slip BC */
        horizontal_bc(E,E->sphere.cap[j].VB,noz,1,E->control.VBXtopval,VBX,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,noz,3,0.0,VBZ,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,noz,2,E->control.VBYtopval,VBY,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,noz,1,0.0,SBX,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,noz,3,0.0,SBZ,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,noz,2,0.0,SBY,0,lv,j);

        if(E->control.vbcs_file){ /* this should either only be called
				     once, or the input routines need
				     to be told what to do for each
				     multigrid level and cap. it might
				     be easiest to call only once and
				     have routines deal with multigrid
				  */
	  if((lv == E->mesh.gridmin) && (j == E->sphere.caps_per_proc))
	     read_velocity_boundary_from_file(E);
	}
      }
      if(E->mesh.botvbc == 1) {	/* velocity bottom BC */
        horizontal_bc(E,E->sphere.cap[j].VB,1,1,E->control.VBXbotval,VBX,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,3,0.0,VBZ,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,2,E->control.VBYbotval,VBY,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,1,0.0,SBX,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,3,0.0,SBZ,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,2,0.0,SBY,0,lv,j);
        }
      else if(E->mesh.botvbc == 2) //open bottom BC
      { 
        horizontal_bc(E,E->sphere.cap[j].VB,1,1,0.0,VBX,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,3,0.0,VBZ,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,2,0.0,VBY,0,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,1,0.0,SBX,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,3,0.0,SBZ,1,lv,j);
        horizontal_bc(E,E->sphere.cap[j].VB,1,2,0.0,SBY,1,lv,j);
      }

      }    /* end for j and lv */

      if(E->control.side_sbcs)
	apply_side_sbc(E);

/* if(E->control.verbose) { */
/*  for (j=1;j<=E->sphere.caps_per_proc;j++) */
/*    for (node=1;node<=E->lmesh.nno;node++) */
/*       fprintf(E->fp_out,"m=%d VB== %d %g %g %g flag %u %u %u\n",j,node,E->sphere.cap[j].VB[1][node],E->sphere.cap[j].VB[2][node],E->sphere.cap[j].VB[3][node],E->node[j][node]&VBX,E->node[j][node]&VBY,E->node[j][node]&VBZ); */
/*  fflush(E->fp_out); */
/* } */

  /* If any imposed internal velocity structure it goes here */


   return; }

/* ========================================== */

void full_temperature_boundary_conditions(E)
     struct All_variables *E;
{
  void temperatures_conform_bcs();
  void temperature_imposed_vert_bcs();
  int j,lev,noz;

  lev = E->mesh.levmax;
  for (j=1;j<=E->sphere.caps_per_proc;j++)    {
    noz = E->mesh.noz;
    if(E->mesh.toptbc == 1)    {
      horizontal_bc(E,E->sphere.cap[j].TB,noz,3,E->control.TBCtopval,TBZ,1,lev,j);
      horizontal_bc(E,E->sphere.cap[j].TB,noz,3,E->control.TBCtopval,FBZ,0,lev,j);
      if(E->control.tbcs_file)
          read_temperature_boundary_from_file(E);
      }
    else   {
      horizontal_bc(E,E->sphere.cap[j].TB,noz,3,E->control.TBCtopval,TBZ,0,lev,j);
      horizontal_bc(E,E->sphere.cap[j].TB,noz,3,E->control.TBCtopval,FBZ,1,lev,j);
      }

    if(E->mesh.bottbc == 1)    {
      horizontal_bc(E,E->sphere.cap[j].TB,1,3,E->control.TBCbotval,TBZ,1,lev,j);
      horizontal_bc(E,E->sphere.cap[j].TB,1,3,E->control.TBCbotval,FBZ,0,lev,j);
      }
    else        {
      horizontal_bc(E,E->sphere.cap[j].TB,1,3,E->control.TBCbotval,TBZ,0,lev,j);
      horizontal_bc(E,E->sphere.cap[j].TB,1,3,E->control.TBCbotval,FBZ,1,lev,j);
      }

    if(E->control.lith_age_time==1)  {

   /* set the regions in which to use lithosphere files to determine temperature
   note that this is called if the lithosphere age in inputted every time step
   OR it is only maintained in the boundary regions */
      lith_age_temperature_bound_adj(E,lev);
    }


    }     /* end for j */

  temperatures_conform_bcs(E);
  E->temperatures_conform_bcs = temperatures_conform_bcs;

   return; }


/*  =========================================================  */


static void horizontal_bc(E,BC,ROW,dirn,value,mask,onoff,level,m)
     struct All_variables *E;
     float *BC[];
     int ROW;
     int dirn;
     float value;
     unsigned int mask;
     char onoff;
     int level,m;

{
  int i,j,node,rowl;

    /* safety feature */
  if(dirn > E->mesh.nsd)
     return;

  if (ROW==1)
      rowl = 1;
  else
      rowl = E->lmesh.NOZ[level];

  if ( ( (ROW==1) && (E->parallel.me_loc[3]==0) ) ||
       ( (ROW==E->mesh.NOZ[level]) && (E->parallel.me_loc[3]==E->parallel.nprocz-1) ) ) {

    /* turn bc marker to zero */
    if (onoff == 0)          {
      for(j=1;j<=E->lmesh.NOY[level];j++)
    	for(i=1;i<=E->lmesh.NOX[level];i++)     {
    	  node = rowl+(i-1)*E->lmesh.NOZ[level]+(j-1)*E->lmesh.NOX[level]*E->lmesh.NOZ[level];
    	  E->NODE[level][m][node] = E->NODE[level][m][node] & (~ mask);
    	  }        /* end for loop i & j */
      }

    /* turn bc marker to one */
    else        {
      for(j=1;j<=E->lmesh.NOY[level];j++)
        for(i=1;i<=E->lmesh.NOX[level];i++)       {
    	  node = rowl+(i-1)*E->lmesh.NOZ[level]+(j-1)*E->lmesh.NOX[level]*E->lmesh.NOZ[level];
    	  E->NODE[level][m][node] = E->NODE[level][m][node] | (mask);
    	  if(level==E->mesh.levmax)   /* NB */
    	    BC[dirn][node] = value;
    	  }     /* end for loop i & j */
      }

    }             /* end for if ROW */

  return;
}


static void velocity_apply_periodic_bcs(E)
    struct All_variables *E;
{
  fprintf(E->fp,"Periodic boundary conditions\n");

  return;
  }

static void temperature_apply_periodic_bcs(E)
    struct All_variables *E;
{
 fprintf(E->fp,"Periodic temperature boundary conditions\n");

  return;
  }



/* version */
/* $Id: Full_boundary_conditions.c 12303 2008-06-21 22:28:51Z becker $ */

/* End of file  */
void plate_velocity_boundary_conditions(E)
    struct All_variables *E;
{

char plate_fname[200];
char continent_fname[200];
char input_s[2000],output_file[255];
static char plate_file[MAX_STAGES][1000];
static char continent_file[MAX_STAGES][1000];

int j,i;
int kk;
int node;
int iznode;
static int iplate_time_dependence=0;
static int been_here=0;

double pvs;
double time_scaling;

double *VPHI[13];
double *VTHETA[13];
static double eee=1.0e-10;

FILE *fp3,*fp5;
FILE *fp4;

void get_plate_velocities_from_file();
void get_continent_from_file();
void check_bc_consistency();

   if (been_here==0)
   {

       E->control.number_of_stages=0;
       E->control.istage_number=1;

      if (E->control.iplate_time_dependence==1)
      {
/* open file */

         if ((fp3=fopen(E->control.plate_fname,"r"))==NULL)
         {
            fprintf(stderr,"ERROR - file %s not found\n",E->control.plate_fname);
            fflush(stderr);
            parallel_process_termination();
         }

         fprintf(E->fp,"Time Dependendent Boundary Conditions\n");
         if (E->parallel.me==0) fprintf(stderr,"Time Dependendent Boundary Conditions\n");
         fprintf(E->fp,"Reading from %s\n",E->control.plate_fname);
         if (E->parallel.me==0) fprintf(stderr,"Reading from %s\n",E->control.plate_fname);
/* time scaling is h^2/kappa */

         time_scaling=1.2867e6;
         time_scaling=E->control.plate_velocity_scaling*E->data.radius_km*100000.0/1.0e6; // in Ma
         E->control.time_end[0]=0.0;

/* read inputs */

         fgets(input_s,1000,fp3);
         sscanf(input_s,"%d",&E->control.number_of_stages);
         if (E->control.number_of_stages>MAX_STAGES)
         {
             fprintf(stderr,"ERROR(plate velocity)-stages %d %d\n",E->control.number_of_stages,MAX_STAGES);
             fprintf(E->fp_out,"ERROR(plate velocity)-stages %d\n",E->control.number_of_stages);
             fflush(stderr);
             fflush(E->fp_out);
             parallel_process_termination();
         }
         for (kk=1;kk<=E->control.number_of_stages;kk++)
         {
            fgets(input_s,1000,fp3);
            sscanf(input_s,"%s %lf %s",plate_file[kk],&E->control.time_duration[kk],continent_file[kk]);
/* scale time */

            E->control.time_duration[kk]=E->control.time_duration[kk]/time_scaling;
            E->control.time_end[kk]=E->control.time_end[kk-1]+E->control.time_duration[kk];

/* test whether file is present */

            if ((fp4=fopen(plate_file[kk],"r"))==NULL)
            {
                fprintf(stderr,"ERROR-file %s not found\n",plate_file[kk]);
                fflush(stderr);
                parallel_process_termination();
            }
		
	if(E->icontinent!=0)
	{
            if ((fp4=fopen(continent_file[kk],"r"))==NULL)
            {
                fprintf(stderr,"ERROR-file %s not found\n",continent_file[kk]);
                fflush(stderr);
                parallel_process_termination();
            }
	}

            fclose(fp4);
         }

         for (kk=1;kk<=E->control.number_of_stages;kk++)
         {
            if (E->parallel.me==0) fprintf(E->fp,"File %s for time %e to %e\n",plate_file[kk],E->control.time_end[kk-1],E->control.time_end[kk]);

         }
      }
      else
      {
         if (E->parallel.me==0)
         {
             fprintf(stderr,"plate_fname: %s\n",E->control.plate_fname);
             fflush(stderr);
         }
      }

/* Set all boundary conditions to 0.0 */

      for (j=1;j<=E->sphere.caps_per_proc;j++)
      {
        for (node=1;node<=E->lmesh.nno;node++)
        {
          E->sphere.cap[j].VB[1][node]=0.0;
          E->sphere.cap[j].VB[2][node]=0.0;
          E->sphere.cap[j].VB[3][node]=0.0;

        }
     }

     been_here++;
     return;

   } /* DONE WITH INITIALIZATION */


/* Zeroeth timestep (first stokes solution) */
if (been_here==1)
{

	if (E->control.iplate_time_dependence==1)
	{

		try_next_stage:;
		/* get correct initial stage */
		if (E->parallel.me==0) {
		fprintf(stderr,"istage_number: %d\n",E->control.istage_number);
		fprintf(stderr,"time: %.4e\n",E->monitor.elapsed_time);
		fprintf(stderr,"time_end: %.4e\n",E->control.time_end[E->control.istage_number]);
		}

		if (E->monitor.elapsed_time>=E->control.time_end[E->control.istage_number])
		{
		E->control.istage_number++;
		if (E->control.istage_number>E->control.number_of_stages)
		{
		fprintf(stderr,"ERROR(plate)-stage number exceeds %d %d\n",E->control.istage_number,E->control.number_of_stages);
		fprintf(E->fp_out,"ERROR(plate)-stage number exceeds %d %d\n",E->control.istage_number,E->control.number_of_stages);
		fflush(stderr);
		fflush(E->fp_out);
		E->control.keep_going=0;
		}
		goto try_next_stage;
		}
		if (E->parallel.me==0) 
		{
		fprintf(stderr,"Plates: stage: %d plate_file: %s\n",E->control.istage_number,plate_file[E->control.istage_number]);
		fprintf(E->fp,"Plates: stage: %d plate_file: %s\n",E->control.istage_number,plate_file[E->control.istage_number]);
		}

		sprintf(plate_fname,"%s",plate_file[E->control.istage_number]);//plate_fname is local variable
		sprintf(continent_fname,"%s",continent_file[E->control.istage_number]);
	}
	else if (E->control.iplate_time_dependence==0)
	{
		sprintf(plate_fname,"%s",E->control.plate_fname);
	}

/* Allocate memory for surface velocity arrays */

	if(E->icontinent!=0)
	{
		get_continent_from_file(E,continent_fname);
	}
	for (j=1;j<=E->sphere.caps_per_proc;j++)
	{
		VPHI[j]=(double *)malloc((E->lmesh.nsf+1)*sizeof(double));
		VTHETA[j]=(double *)malloc((E->lmesh.nsf+1)*sizeof(double));
	}
	  
       get_plate_velocities_from_file(E,plate_fname,VTHETA,VPHI);

       pvs=E->control.plate_velocity_scaling;
       for (j=1;j<=E->sphere.caps_per_proc;j++)
       {
          iznode=0;
          for (node=1;node<=E->lmesh.nno;node++)
          {
              E->sphere.cap[j].VB[1][node]=0.0;
              E->sphere.cap[j].VB[2][node]=0.0;
              E->sphere.cap[j].VB[3][node]=0.0;

             if (node%E->lmesh.noz==0)
             {
                iznode++;
                E->sphere.cap[j].VB[1][node]=pvs*VTHETA[j][iznode];
                E->sphere.cap[j].VB[2][node]=pvs*VPHI[j][iznode];
                E->sphere.cap[j].VB[3][node]=0.0;
             }
          }
       }
       for (j=1;j<=E->sphere.caps_per_proc;j++)
       {
          free(VPHI[j]);
          free(VTHETA[j]);
       }

       check_bc_consistency(E);

       been_here++;
       return;

    }  /* Done with Zeroeth timestep */

   if (E->control.iplate_time_dependence==0) return;

/* For subsequent timestep when using time-dependent velocity conditions */

   if (been_here>1)
   {
/* If still in previous stage, return. Otherwise, advance stage */

//  eee=1e-10 is small but large enough to push istage to next stage to use
//  plate motion for next stage at time_end
//
      if ((E->monitor.elapsed_time+eee)<E->control.time_end[E->control.istage_number])
      {
          if (E->parallel.me==0) fprintf(stderr,"Plates_stage: %d plate_file: %s continent_file: %s time:%.4e time_end:%.4e\n",E->control.istage_number,plate_file[E->control.istage_number],continent_file[E->control.istage_number],E->monitor.elapsed_time,E->control.time_end[E->control.istage_number]);

          return;
      }
      else
      {
         E->control.istage_number++;
/* Do post processing and stop calculation if done */

        if (E->control.istage_number>E->control.number_of_stages)
        {

           fprintf(stderr,"Done with time-dependent plate calculation!\n");
           fflush(stderr);
           E->control.keep_going=0;   
                // this should have already done in check_for_velo_bc_istage
           return;
//           parallel_process_termination();
        }
        if (E->monitor.elapsed_time>E->control.time_end[E->control.istage_number])
        {
           //fprintf(E->fptime,"ERROR(plate boundaries) 2 Stages per timestep - something wrong here!\n");
           fprintf(stderr,"ERROR(plate boundaries) 2 Stages per timestep - something wrong here!\n");
           fprintf(stderr,"STAGE: %d ENDTIME: %f TIME: %f\n",E->control.istage_number,E->control.time_end[E->control.istage_number],E->monitor.elapsed_time);
           fflush(stderr);
          // fflush(E->fptime);
           parallel_process_termination();
        }
        sprintf(plate_fname,"%s",plate_file[E->control.istage_number]);

        if (E->parallel.me==0) fprintf(stderr,"Plates_NEW stage: %d plate_file: %s cont_file: %s time: %e step: %d time_end:%.4e\n",E->control.istage_number,plate_file[E->control.istage_number],continent_file[E->control.istage_number],E->monitor.elapsed_time,E->monitor.solution_cycles,E->control.time_end[E->control.istage_number]);
        if (E->parallel.me==0) fprintf(E->fp,"Plates_NEW stage: %d plate_file: %s cont_file: %s time: %e step: %d time_end:%.4e\n",E->control.istage_number,plate_file[E->control.istage_number],continent_file[E->control.istage_number],E->monitor.elapsed_time,E->monitor.solution_cycles,E->control.time_end[E->control.istage_number]);

	(E->problem_output)(E, E->monitor.solution_cycles);//limm add

        sprintf(continent_fname,"%s",continent_file[E->control.istage_number]);

	if(E->icontinent!=0)
	{
		get_continent_from_file(E,continent_fname);
	}

        for (j=1;j<=E->sphere.caps_per_proc;j++)
        {
           VPHI[j]=(double *)malloc((E->lmesh.nsf+1)*sizeof(double));
           VTHETA[j]=(double *)malloc((E->lmesh.nsf+1)*sizeof(double));
        }
        get_plate_velocities_from_file(E,plate_fname,VTHETA,VPHI);
        pvs=E->control.plate_velocity_scaling;
        for (j=1;j<=E->sphere.caps_per_proc;j++)
        {
            iznode=0;
            for (node=1;node<=E->lmesh.nno;node++)
            {
                E->sphere.cap[j].VB[1][node]=0.0;
                E->sphere.cap[j].VB[2][node]=0.0;
                E->sphere.cap[j].VB[3][node]=0.0;

                if (node%E->lmesh.noz==0)
                {
                   iznode++;
                   E->sphere.cap[j].VB[1][node]=pvs*VTHETA[j][iznode];
                   E->sphere.cap[j].VB[2][node]=pvs*VPHI[j][iznode];
                   E->sphere.cap[j].VB[3][node]=0.0;
                }
            }
        }
        for (j=1;j<=E->sphere.caps_per_proc;j++)
        {
           free(VPHI[j]);
           free(VTHETA[j]);
        }

        check_bc_consistency(E);

     } /* end if new stage */

   }
/* End if subsequent steps */


return;
}

/****************** GET PLATE VELOCITIES FROM FILE *****************************/
/*                                                                             */
/* This function gets plate velocities from Carolina's plate file              */
void get_plate_velocities_from_file(E,plate_fname,VTHETA,VPHI)
   struct All_variables *E;
   char *plate_fname;
   double **VTHETA;
   double **VPHI;
{

char input_s[1000];

int numtheta,numphi,nregnodes;
int kk,j;
int ntheta,nphi,iregnode,iregnode2;
int node;
int c1,c2,c3,c4;
int isurface_element;

double del_degree;
double del_theta;
double del_phi;
double lat_min,lat_max;
double theta_min,theta_max;
double phi_min,phi_max;
double vtheta,vphi;
double rlat,rlong;
double *regular_vtheta;
double *regular_vphi;
double theta,phi;
double phiprime,thetaprime;
double xi,eta;
double shape1,shape2,shape3,shape4;
double veltheta,velphi;
double oneplussmall,neg_oneplussmall;
char output_file[255];//nanzhang
FILE *fp2,*fp_nan;

if(E->parallel.me==0)
{
	fprintf(stderr,"get plate velocity from %s\n",plate_fname);
}

/* INPUT FILE SPECIFIC STUFF */
/* format longitude, latitude, vphi, vtheta (vtheta is opposite in convention) */
/* file sequence given in specific order (see below):                          */
/* inputfile specific parameters:                                              */

   del_degree=1.0;           /* increments given in input file */
   lat_min=-89.5;            /* minimum lattitude */
   lat_max=89.5;             /* maximum lattitude */
   phi_min=0.5;             /* minimum longitude */
   phi_max=359.5;           /* maximum longitude */
   numtheta=180;             /* number of theta increments */
   numphi=360;               /* number of phi increments */
   del_theta=del_degree*M_PI/180.0;
   del_phi=del_degree*M_PI/180.0;
   theta_min=-1.0*(lat_max-90.0)*M_PI/180.0;
   theta_max=-1.0*(lat_min-90.0)*M_PI/180.0;
   phi_min=phi_min*M_PI/180.0;
   phi_max=phi_max*M_PI/180.0;
   oneplussmall= 1.0+1e-6;
   neg_oneplussmall= -oneplussmall;

   nregnodes=numtheta*numphi;

/* adjust parameters for ghosting - extra regular elements are added on all sides */
/* This is required to interpolate nodes between thetamin and thetamax, and phimin and phimax */
/* Domain is padded by extra +2 numphi and +2 numtheta */

   numtheta=numtheta+2;
   numphi=numphi+2;
   theta_min=theta_min-del_theta;
   theta_max=theta_max+del_theta;
   phi_min=phi_min-del_phi;
   phi_max=phi_max+del_phi;

   nregnodes=numtheta*numphi;

   if ( ((numphi%2)!=0)||((numtheta%2)!=0))
   {
     fprintf(stderr,"ERROR(interpolate surface..)-numphi and numtheta must be even %d %d\n",numphi,numtheta);
     fflush(stderr);
     exit(10);
   }

   regular_vtheta=(double *)malloc((nregnodes+1)*sizeof(double));
   regular_vphi=(double *)malloc((nregnodes+1)*sizeof(double));

/* read from file */

   if ( (fp2=fopen(plate_fname,"r"))==NULL)
   {
      fprintf(stderr,"ERROR(plate_velocity_boundary_cond)- file %s not found\n",plate_fname);
      fflush(stderr);
      parallel_process_termination();
   }

   for (kk=1;kk<=nregnodes;kk++)
   {
      regular_vtheta[kk]=-999999;
      regular_vphi[kk]=-999999;
   }

/* input file specific order of reading  right here */
/* (note - leaving room for ghosting) */
   for (ntheta=(numtheta-1);ntheta>1;ntheta--)
   {
   for (nphi=2;nphi<=(numphi-1);nphi++)
   {

      iregnode=ntheta+(nphi-1)*numtheta;

      if ((iregnode>nregnodes)||(iregnode<1))
      {
        fprintf(stderr,"ERROR(plate velocities)-wrong iregnode %d %d\n",iregnode,nregnodes);
        fflush(stderr);
        exit(10);
      }

      fgets(input_s,1000,fp2);
      sscanf(input_s,"%lf %lf %le %le",&rlong,&rlat,&vphi,&vtheta);

/* reverse vtheta to fit with convention */

      regular_vtheta[iregnode]=-1.0*vtheta;
      regular_vphi[iregnode]=vphi;

   }
   }

/* ghost sides of regular domain */
   nphi=1;
   for (ntheta=2;ntheta<=(numtheta-1);ntheta++)
   {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=ntheta+((numphi-1)-1)*numtheta;
      regular_vtheta[iregnode]=regular_vtheta[iregnode2];
      regular_vphi[iregnode]=regular_vphi[iregnode2];
   }

   nphi=numphi;
   for (ntheta=2;ntheta<=(numtheta-1);ntheta++)
   {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=ntheta+(2-1)*numtheta;
      regular_vtheta[iregnode]=regular_vtheta[iregnode2];
      regular_vphi[iregnode]=regular_vphi[iregnode2];
   }

   ntheta=1;
   for (nphi=1;nphi<=(numphi/2);nphi++)
   {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=(ntheta+1)+(nphi+numphi/2-1)*numtheta;
      regular_vtheta[iregnode]=regular_vtheta[iregnode2];
      regular_vphi[iregnode]=regular_vphi[iregnode2];
   }
   for (nphi=(numphi/2)+1;nphi<=numphi;nphi++)
   {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=(ntheta+1)+(nphi-(numphi/2)-1)*numtheta;
      regular_vtheta[iregnode]=regular_vtheta[iregnode2];
      regular_vphi[iregnode]=regular_vphi[iregnode2];
   }

   ntheta=(numtheta);
   for (nphi=1;nphi<=(numphi/2);nphi++)
   {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=(ntheta-1)+(nphi+numphi/2-1)*numtheta;
      regular_vtheta[iregnode]=regular_vtheta[iregnode2];
      regular_vphi[iregnode]=regular_vphi[iregnode2];
   }
   for (nphi=(numphi/2)+1;nphi<=numphi;nphi++)
   {
      iregnode=ntheta+(nphi-1)*numtheta;
      iregnode2=(ntheta-1)+(nphi-(numphi/2)-1)*numtheta;
      regular_vtheta[iregnode]=regular_vtheta[iregnode2];
      regular_vphi[iregnode]=regular_vphi[iregnode2];
   }

/* testing - make sure ghosting worked */
   for (ntheta=1;ntheta<=numtheta;ntheta++)
   for (nphi=1;nphi<=numphi;nphi++)
   {
      iregnode=ntheta+(nphi-1)*numtheta;
      if ((regular_vtheta[iregnode]==-999999) || (regular_vphi[iregnode]==-999999))
      {
          fprintf(stderr,"ERROR(plate vel)-something wrong (A)\n");
          fprintf(stderr,"(perhaps ntheta or nphi? ntheta:%d nphi:%d \n ",ntheta,nphi);
          fflush(stderr);
          exit(10);
      }
   }

   for (kk=1;kk<=nregnodes;kk++)
   {
      if ((regular_vtheta[kk]==-999999) || (regular_vphi[kk]==-999999))
      {
          fprintf(stderr,"ERROR(plate vel)-something wrong (B)\n");
          fprintf(stderr,"(perhaps ntheta or nphi? %d \n ",kk);
          fflush(stderr);
          exit(10);
      }
   }
/* end testing */

/* interpolate real mesh */
  //sprintf(output_file,"%s.surfv_debug.%d.%d",E->control.data_file2,E->parallel.me,E->monitor.solution_cycles);
  //fp_nan=fopen(output_file,"w");
  isurface_element=0;
  for (j=1;j<=E->sphere.caps_per_proc;j++)
  {
     for (node=1;node<=E->lmesh.nno;node++)
     {
         theta=E->sx[j][1][node];
         phi=E->sx[j][2][node];
         if (node%E->lmesh.noz==0)
         {
            isurface_element++;
/* find position on regular mesh */
            ntheta=((theta-theta_min)/del_theta)+1;
            nphi=((phi-phi_min)/del_phi)+1;
/* iregnode is the lower left node in the regular element */
 
            iregnode=ntheta+(nphi-1)*numtheta;

/* find theta and phi distance from node */
        thetaprime=theta-(theta_min+(ntheta-1)*del_theta);
        phiprime=phi-(phi_min+(nphi-1)*del_phi);

        if (thetaprime<0.0 || thetaprime>del_theta)
        {
           fprintf(stderr,"ERROR(get plate velocities)-wierd thetaprime %f %f\n",thetaprime,del_theta);
           fflush(stderr);
           exit(10);
        }
        if (phiprime<0.0 || phiprime>del_phi)
        {
           fprintf(stderr,"ERROR(get plate velocities)-wierd phiprime %f %f\n",phiprime,del_phi);
           fflush(stderr);
           exit(10);
        }

/* determine shape functions */

       xi=2.0/del_theta*thetaprime-1.0;
       eta=2.0/del_phi*phiprime-1.0;


//       if (xi<(-1-1e-6) || xi > (1+1e-6) || eta < (-1-1e-6) || eta > (1+1e-6))
       if (xi<neg_oneplussmall || xi > oneplussmall || eta < neg_oneplussmall || eta > oneplussmall)
       {
          fprintf(stderr,"bad local variables %f %f (%f %f) (%f %f)\n",xi,eta,thetaprime,phiprime,del_theta,del_phi);
          fflush(stderr);
          exit(10);
       }

       shape1=0.25*(1.0-xi)*(1.0-eta);
       shape2=0.25*(1.0+xi)*(1.0-eta);
       shape3=0.25*(1.0+xi)*(1.0+eta);
       shape4=0.25*(1.0-xi)*(1.0+eta);

       c1=iregnode;
       c2=iregnode+1;
       c3=iregnode+1+numtheta;
       c4=iregnode+numtheta;

       if ( (c3>(numtheta*numphi)) || (c1<1) )
       {
         fprintf(stderr,"ERROR(get plate...) - %d %d %d %d\n",c1,c2,c3,c4);
         fflush(stderr);
         exit(10);
       }
       veltheta=regular_vtheta[c1]*shape1+regular_vtheta[c2]*shape2+regular_vtheta[c3]*shape3+regular_vtheta[c4]*shape4;
       velphi=regular_vphi[c1]*shape1+regular_vphi[c2]*shape2+regular_vphi[c3]*shape3+regular_vphi[c4]*shape4;

       VTHETA[j][isurface_element]=veltheta;
       VPHI[j][isurface_element]=velphi;
      //nanzhang output for debug
      //fprintf(fp_nan,"%lf %lf %lf %lf\n",phi*180/M_PI,90-theta*180/M_PI,velphi,-1.0*veltheta);
       }//if over
   }
   }
   //fclose(fp_nan);
   free(regular_vtheta);
   free(regular_vphi);

return;
}

void check_for_velo_bc_istage(E)
    struct All_variables *E;
{

 double time_temp;

 time_temp = E->monitor.elapsed_time + E->advection.timestep;

  if (time_temp>=E->control.time_end[E->control.istage_number])  {
     E->advection.timestep = E->control.time_end[E->control.istage_number]-E->monitor.elapsed_time;
     if (E->control.istage_number+1>E->control.number_of_stages) 
        E->control.keep_going=0;
     }

 return;
}

void compute_plate_velocity(E)
    struct All_variables *E;
{
int i,j,iznode,node,inoz;
char plate_fname[200];
char tempstring[256];
double *VPHI[13];
double *VTHETA[13];
double pvs;
FILE *fp;
for(i=0;i<=199;i++)
{
        sprintf(plate_fname,"/glade/u/home/mingl/cs/Plate_Motions/S200/S200_shifted_%d",i);
	if(E->parallel.me==0)
	fprintf(stderr,"saving plate velocity file %d\n",i);

        for (j=1;j<=E->sphere.caps_per_proc;j++)
        {
                VPHI[j]=(double *)malloc((E->lmesh.nsf+1)*sizeof(double));
                VTHETA[j]=(double *)malloc((E->lmesh.nsf+1)*sizeof(double));
        }

        get_plate_velocities_from_file(E,plate_fname,VTHETA,VPHI);

        pvs=E->control.plate_velocity_scaling;
        for (j=1;j<=E->sphere.caps_per_proc;j++)
        {
	    for(iznode=1;iznode<=E->lmesh.nsf;iznode++)
            for (inoz=1;inoz<=E->lmesh.noz;inoz++)
            {
		node=inoz+(iznode-1)*E->lmesh.noz;
		E->sphere.cap[j].V[1][node]=pvs*VTHETA[j][iznode];
		E->sphere.cap[j].V[2][node]=pvs*VPHI[j][iznode];
		E->sphere.cap[j].V[3][node]=0.0;
            }
        }


        sprintf(tempstring,"%s/plate.%d.%d",E->control.data_dir,E->parallel.me,i);
	fp=fopen(tempstring,"w");
	
        for (j=1;j<=E->sphere.caps_per_proc;j++)
	for(iznode=1;iznode<=E->lmesh.nsf;iznode++)
	{
		node=iznode*E->lmesh.noz;
		fprintf(fp,"%.6e %.6e\n",E->sphere.cap[j].V[1][node],E->sphere.cap[j].V[2][node]);
	}
	fclose(fp);
	

        for (j=1;j<=E->sphere.caps_per_proc;j++)
        {
           free(VPHI[j]);
           free(VTHETA[j]);
        }

}
return;
}

void get_continent_from_file(E,continent_fname)
   struct All_variables *E;
   char *continent_fname;
{
FILE *fp;
float lon,lat,continent,theta,phi;
char input_s[256];
int i,j,node,ii,jj;
float cont[361][181];
int m=1;

fp=fopen(continent_fname,"r");

for(i=0;i<=360;i++)
for(j=0;j<=180;j++)
{
	fgets(input_s,256,fp);
	sscanf(input_s,"%f %f %f",&lon,&lat,&cont[i][j]);
}

for(i=1;i<=E->lmesh.nsf;i++)
{
	node=i*E->lmesh.noz;
	theta=E->sx[m][1][node]*180.0/M_PI;
	phi=E->sx[m][2][node]*180.0/M_PI;
	ii=(int)(phi);
	jj=(int)(theta);
	if(ii<0 || jj<0)
	{
		fprintf(stderr,"something is wrong\n");
            	parallel_process_termination();
	}
	if(cont[ii][jj]>0.0)
	{
		E->continent[i]=1;
	}
	else
	{
		E->continent[i]=0;
	}
}

fclose(fp);
return;
}

void remove_surface_net_rotation(E)
	struct All_variables *E;
{
    void velo_from_element_d();
    double myatan();
    double wx, wy, wz, v_theta, v_phi, cos_t,sin_t,sin_f, cos_f,frd;
    double vx[9], vy[9], vz[9];
    double r, t, f, efac,tg;
    float cart_base[9];
    double exyz[4], fxyz[4];

    int m, e, i, k, j, node;
    const int lev = E->mesh.levmax;
    const int nno = E->lmesh.nno;
    const int ends = ENODES3D;
    const int ppts = PPOINTS3D;
    const int vpts = VPOINTS3D;
    const int sphere_key = 1;
    double VV[4][9];
    double rot, fr, tr;
    double tmp, moment_of_inertia, rho;
    float *Vtemp[4];
	int node1,node2,ii;


if (E->parallel.me==0) 
{
	fprintf(E->fp,"surface net rotaion removed\n");
	fprintf(stderr,"surface net rotaion removed\n");
}

if(E->sphere.caps_per_proc!=1)
{
	fprintf(stderr,"ddddddddddddddddddddd\n");
	terminate();
}

for(i=1;i<=3;i++)
	Vtemp[i] = (float *) malloc((E->lmesh.nnov+1)*sizeof(float));

for(node=1;node<=E->lmesh.nno;node++)
{
	for(i=1;i<=3;i++)
	{
		Vtemp[i][node]=E->sphere.cap[1].V[i][node];
	}
}

//make all velocity equal to surface velocity

for(j=1;j<=E->lmesh.noy;j++)
for(i=1;i<=E->lmesh.nox;i++)
for(k=1;k<=E->lmesh.noz;k++)
{
	node1=k+(i-1)*E->lmesh.noz+(j-1)*E->lmesh.nox*E->lmesh.noz;
	node2=E->lmesh.noz+(i-1)*E->lmesh.noz+(j-1)*E->lmesh.nox*E->lmesh.noz;
	for(ii=1;ii<=2;ii++)
	{
		E->sphere.cap[1].V[ii][node1]=E->sphere.cap[1].VB[ii][node2];
	}
}

remove_rigid_rot(E);

for (m=1;m<=E->sphere.caps_per_proc;m++)  
{
	for (node=E->lmesh.noz;node<=nno;node=node+E->lmesh.noz)   
	{
		E->sphere.cap[m].VB[1][node] = E->sphere.cap[m].V[1][node];
		E->sphere.cap[m].VB[2][node] = E->sphere.cap[m].V[2][node];
	}
}

for(node=1;node<=E->lmesh.nno;node++)
{
	for(i=1;i<=3;i++)
	{
		E->sphere.cap[1].V[i][node]=Vtemp[i][node];
	}
}


for(i=1;i<=3;i++)
	free(Vtemp[i]);
return;
}
