

/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *<LicenseText>
 *
 * CitcomS by Louis Moresi, Shijie Zhong, Lijie Han, Eh Tan,
 * Clint Conrad, Michael Gurnis, and Eun-seo Choi.
 * Copyright (C) 1994-2005, California Institute of Technology.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *</LicenseText>
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
/*

  Tracer_setup.c

      A program which initiates the distribution of tracers
      and advects those tracers in a time evolving velocity field.
      Called and used from the CitCOM finite element code.
      Written 2/96 M. Gurnis for Citcom in cartesian geometry
      Modified by Lijie in 1998 and by Vlad and Eh in 2005 for the
      regional version of CitcomS. In 2003, Allen McNamara wrote the
      tracer module for the global version of CitcomS. In 2007, Eh Tan
      merged the two versions of tracer codes together.
*/

#include <math.h>
#include "global_defs.h"
#include "element_definitions.h"
#include "parsing.h"
#include "parallel_related.h"
#include "composition_related.h"
#include <fcntl.h>
#ifdef USE_GGRD
#include "ggrd_handling.h"
#endif

#ifdef USE_GZDIR
int open_file_zipped(char *, FILE **,struct All_variables *);
void gzip_file(char *);
#endif

int icheck_that_processor_shell(struct All_variables *E,
                                       int j, int nprocessor, double rad);
void expand_later_array(struct All_variables *E, int j);
void expand_tracer_arrays(struct All_variables *E, int j);
void tracer_post_processing(struct All_variables *E);
void allocate_tracer_arrays(struct All_variables *E,
                            int j, int number_of_tracers);
void count_tracers_of_flavors(struct All_variables *E);

int full_icheck_cap(struct All_variables *E, int icap,
                    double x, double y, double z, double rad);
int regional_icheck_cap(struct All_variables *E, int icap,
                        double x, double y, double z, double rad);

static void find_tracers(struct All_variables *E);
static void predict_tracers(struct All_variables *E);
static void correct_tracers(struct All_variables *E);
static void make_tracer_array(struct All_variables *E);
static void generate_random_tracers(struct All_variables *E,
                                    int tracers_cap, int j);
static void read_tracer_file(struct All_variables *E);
static void read_old_tracer_file(struct All_variables *E);
static void check_sum(struct All_variables *E);
static int isum_tracers(struct All_variables *E);
static void init_tracer_flavors(struct All_variables *E);
static void reduce_tracer_arrays(struct All_variables *E);
static void put_away_later(struct All_variables *E, int j, int it);
static void eject_tracer(struct All_variables *E, int j, int it);
int read_double_vector(FILE *, int , double *);
void cart_to_sphere(struct All_variables *,
                    double , double , double ,
                    double *, double *, double *);
void sphere_to_cart(struct All_variables *,
                    double , double , double ,
                    double *, double *, double *);
int icheck_processor_shell(struct All_variables *,
                           int , double );

void add_layered_composition(struct All_variables *E);
void add_continents(struct All_variables *E);

void tracer_input(struct All_variables *E)
{
    void full_tracer_input();
    void myerror();
    void report();
    char message[100];
    int m=E->parallel.me;
    int i;

    input_boolean("tracer",&(E->control.tracer),"off",m);
    input_boolean("tracer_enriched",
		  &(E->control.tracer_enriched),"off",m);
    if(E->control.tracer_enriched){
      if(!E->control.tracer)	/* check here so that we can get away
				   with only one if statement in
				   Advection_diffusion */
	myerror(E,"need to switch on tracers for tracer_enriched");

      input_float("Q0_enriched",&(E->control.Q0ER),"0.0",m);
      snprintf(message,100,"using compositionally enriched heating: C = 0: %g C = 1: %g (only one composition!)",
	       E->control.Q0,E->control.Q0ER);
      report(E,message);
      //
      // this check doesn't work at this point in the code, and we didn't want to put it into every call to
      // Advection diffusion
      //
      //if(E->composition.ncomp != 1)
      //myerror(E,"enriched tracers cannot deal with more than one composition yet");

    }
    if(E->control.tracer) {

        /* tracer_ic_method=0 (random generated array) */
        /* tracer_ic_method=1 (all proc read the same file) */
        /* tracer_ic_method=2 (each proc reads its restart file) */
        input_int("tracer_ic_method",&(E->trace.ic_method),"0,0,nomax",m);

        if (E->trace.ic_method==0){
            input_int("tracers_per_element",&(E->trace.itperel),"10,0,nomax",m);
	}
        else if (E->trace.ic_method==1)
            input_string("tracer_file",E->trace.tracer_file,"tracer.dat",m);
        else if (E->trace.ic_method==2) {
            /* Use 'datadir_old', 'datafile_old', and 'solution_cycles_init' */
            /* to form the filename */
        }
        else {
            fprintf(stderr,"Sorry, tracer_ic_method only 0, 1 and 2 available\n");
            parallel_process_termination();
        }


        /* How many flavors of tracers */
        /* If tracer_flavors > 0, each element will report the number of
         * tracers of each flavor inside it. This information can be used
         * later for many purposes. One of it is to compute composition,
         * either using absolute method or ratio method. */
        input_int("tracer_flavors",&(E->trace.nflavors),"0,0,nomax",m);

	/* 0: default from layers 
	   1: from netcdf grds
	   
	   
	   99: from grds, overriding checkpoints during restart
	   (1 and 99 require ggrd)
	*/

        input_int("ic_method_for_flavors",
		  &(E->trace.ic_method_for_flavors),"0,0,nomax",m);

                E->trace.z_interface = (double*) malloc((E->trace.nflavors-1)
                                                        *sizeof(double));
                for(i=0; i<E->trace.nflavors-1; i++)
                    E->trace.z_interface[i] = 0.7;

                input_double_vector("z_interface", E->trace.nflavors-1,
                                    E->trace.z_interface, m);

	      	input_int("number_of_continents",&(E->trace.number_of_continents),"1",m);
	      	input_int("continent_flavor",&(E->trace.continent_flavor),"1",m);
		E->trace.radius_of_continents=	(double*) malloc((E->trace.number_of_continents)
							*sizeof(double));
		E->trace.lat_of_continents=	(double*) malloc((E->trace.number_of_continents)
							*sizeof(double));
		E->trace.lon_of_continents=	(double*) malloc((E->trace.number_of_continents)
							*sizeof(double));

                input_double_vector("radius_of_continents", E->trace.number_of_continents,
                                    E->trace.radius_of_continents, m);
                input_double_vector("lat_of_continents", E->trace.number_of_continents,
                                    E->trace.lat_of_continents, m);
                input_double_vector("lon_of_continents", E->trace.number_of_continents,
                                    E->trace.lon_of_continents, m);

		for(i=0;i<E->trace.number_of_continents;i++)
		{
			E->trace.radius_of_continents[i]=E->trace.radius_of_continents[i]*M_PI/180.0;
			E->trace.lat_of_continents[i]=E->trace.lat_of_continents[i]*M_PI/180.0;
			E->trace.lon_of_continents[i]=E->trace.lon_of_continents[i]*M_PI/180.0;
		}

/*
        if (E->trace.nflavors > 1) {
            switch(E->trace.ic_method_for_flavors){
            case 0:			
                E->trace.z_interface = (double*) malloc((E->trace.nflavors-1)
                                                        *sizeof(double));
                for(i=0; i<E->trace.nflavors-1; i++)
                    E->trace.z_interface[i] = 0.7;

                input_double_vector("z_interface", E->trace.nflavors-1,
                                    E->trace.z_interface, m);
                break;
            case 1:
	      	input_int("number_of_continents",&(E->trace.number_of_continents),"1",m);
		E->trace.radius_of_continents=	(double*) malloc((E->trace.number_of_continents)
							*sizeof(double));
		E->trace.lat_of_continents=	(double*) malloc((E->trace.number_of_continents)
							*sizeof(double));
		E->trace.lon_of_continents=	(double*) malloc((E->trace.number_of_continents)
							*sizeof(double));

                input_double_vector("radius_of_continents", E->trace.number_of_continents,
                                    E->trace.radius_of_continents, m);
                input_double_vector("lat_of_continents", E->trace.number_of_continents,
                                    E->trace.lat_of_continents, m);
                input_double_vector("lon_of_continents", E->trace.number_of_continents,
                                    E->trace.lon_of_continents, m);

		for(i=0;i<E->trace.number_of_continents;i++)
		{
			E->trace.radius_of_continents[i]=E->trace.radius_of_continents[i]*M_PI/180.0;
			E->trace.lat_of_continents[i]=E->trace.lat_of_continents[i]*M_PI/180.0;
			E->trace.lon_of_continents[i]=E->trace.lon_of_continents[i]*M_PI/180.0;
		}
		
		break;

#ifdef USE_GGRD
	    case 99:
	      input_string("ictracer_grd_file",E->trace.ggrd_file,"",m); 
	      input_int("ictracer_grd_layers",&(E->trace.ggrd_layers),"2",m);
	      break;
#endif
            default:
                fprintf(stderr,"ic_method_for_flavors %i undefined\n",E->trace.ic_method_for_flavors);
                parallel_process_termination();
                break;
            }

        }
*/

        /* Warning level */
        input_boolean("itracer_warnings",&(E->trace.itracer_warnings),"on",m);


        if(E->parallel.nprocxy == 12)
            full_tracer_input(E);


        composition_input(E);

    }

    return;
}


void tracer_initial_settings(struct All_variables *E)
{
   void full_keep_within_bounds();
   void full_tracer_setup();
   void full_get_velocity();
   int full_iget_element();
   void regional_keep_within_bounds();
   void regional_tracer_setup();
   void regional_get_velocity();
   int regional_iget_element();

   E->trace.advection_time = 0;
   E->trace.find_tracers_time = 0;
   E->trace.lost_souls_time = 0;

   if(E->parallel.nprocxy == 1) {
       E->problem_tracer_setup = regional_tracer_setup;

       E->trace.keep_within_bounds = regional_keep_within_bounds;
       E->trace.get_velocity = regional_get_velocity;
       //E->trace.iget_element = regional_iget_element;
   }
   else {
       E->problem_tracer_setup = full_tracer_setup;

       E->trace.keep_within_bounds = full_keep_within_bounds;
       E->trace.get_velocity = full_get_velocity;
       E->trace.iget_element = full_iget_element;
   }
}



/*****************************************************************************/
/* This function is the primary tracing routine called from Citcom.c         */
/* In this code, unlike the original 3D cartesian code, force is filled      */
/* during Stokes solution. No need to call thermal_buoyancy() after tracing. */


void tracer_advection(struct All_variables *E)
{
    double CPU_time0();
    double begin_time = CPU_time0();
    void update_age();
	void calculate_melting_flux();
	void make_crust();
	void adjust_buoyancy_ratio();
	int i;

    /* advect tracers */
    predict_tracers(E);
    correct_tracers(E);

	if(E->control.melt_flux!=0)
	{
		calculate_melting_flux(E);
	}

	if(E->control.make_crust!=0)
	{
		make_crust(E);
	}

    /* check that the number of tracers is conserved */
    check_sum(E);

    //update_age(E);//nanzhang 2010
    /* count # of tracers of each flavor */
    if (E->trace.nflavors > 0)
        count_tracers_of_flavors(E);

    /* update the composition field */
    if (E->composition.on) {
        fill_composition(E);
    }

/*
if(E->monitor.solution_cycles%100==0 && E->monitor.runtime-E->monitor.elapsed_time*1.288e6>300.0)
//if(E->monitor.runtime-E->monitor.elapsed_time*1.288e6>250.0)
{
	for (i=0; i<E->composition.ncomp; i++)
	{
		if(E->composition.adjustable_B[i]==1)
		{
			adjust_buoyancy_ratio(E,i);
		}
	}
}
*/


    E->trace.advection_time += CPU_time0() - begin_time;

    tracer_post_processing(E);

    return;
}



/********* TRACER POST PROCESSING ****************************************/

void tracer_post_processing(struct All_variables *E)
{
    int i;

    /* reset statistical counters */

    E->trace.istat_isend=0;
    E->trace.istat_elements_checked=0;
    E->trace.istat1=0;

    /* write timing information every 20 steps */
    if ((E->monitor.solution_cycles % 20) == 0) {
        fprintf(E->trace.fpt, "STEP %d\n", E->monitor.solution_cycles);

        fprintf(E->trace.fpt, "Advecting tracers takes %f seconds.\n",
                E->trace.advection_time - E->trace.find_tracers_time);
        fprintf(E->trace.fpt, "Finding element takes %f seconds.\n",
                E->trace.find_tracers_time - E->trace.lost_souls_time);
        fprintf(E->trace.fpt, "Exchanging lost tracers takes %f seconds.\n",
                E->trace.lost_souls_time);
    }

    if(E->control.verbose){
      fprintf(E->trace.fpt,"Number of times for all element search  %d\n",E->trace.istat1);

      fprintf(E->trace.fpt,"Number of tracers sent to other processors: %d\n",E->trace.istat_isend);

      fprintf(E->trace.fpt,"Number of times element columns are checked: %d \n",E->trace.istat_elements_checked);

      /* compositional and error fraction data files */
      //TODO: move
      if (E->composition.on) {
        fprintf(E->trace.fpt,"Empty elements filled with old compositional "
                "values: %d (%f percent)\n", E->trace.istat_iempty,
                (100.0*E->trace.istat_iempty)/E->lmesh.nel);
        E->trace.istat_iempty=0;


        get_bulk_composition(E);

        if (E->parallel.me==0) {

            fprintf(E->fp,"composition: %e",E->monitor.elapsed_time);
            for (i=0; i<E->composition.ncomp; i++)
                fprintf(E->fp," %e", E->composition.bulk_composition[i]);
            fprintf(E->fp,"\n");

            fprintf(E->fp,"composition_error_fraction: %e",E->monitor.elapsed_time);
            for (i=0; i<E->composition.ncomp; i++)
                fprintf(E->fp," %e", E->composition.error_fraction[i]);
            fprintf(E->fp,"\n");

        }
      }
      fflush(E->trace.fpt);
    }

    return;
}


/*********** PREDICT TRACERS **********************************************/
/*                                                                        */
/* This function predicts tracers performing an euler step                */
/*                                                                        */
/*                                                                        */
/* Note positions used in tracer array                                    */
/* [positions 0-5 are always fixed with current coordinates               */
/*  Positions 6-8 contain original Cartesian coordinates.                 */
/*  Positions 9-11 contain original Cartesian velocities.                 */
/*                                                                        */


static void predict_tracers(struct All_variables *E)
{

    int numtracers;
    int j;
    int kk;
    int nelem;

    double dt;
    double theta0,phi0,rad0;
    double x0,y0,z0;
    double theta_pred,phi_pred,rad_pred;
    double x_pred,y_pred,z_pred;
    double velocity_vector[4];

    void cart_to_sphere();


    dt=E->advection.timestep;


    for (j=1;j<=E->sphere.caps_per_proc;j++) {

        numtracers=E->trace.ntracers[j];

        for (kk=1;kk<=numtracers;kk++) {

            theta0=E->trace.basicq[j][0][kk];
            phi0=E->trace.basicq[j][1][kk];
            rad0=E->trace.basicq[j][2][kk];
            x0=E->trace.basicq[j][3][kk];
            y0=E->trace.basicq[j][4][kk];
            z0=E->trace.basicq[j][5][kk];
            nelem=E->trace.ielement[j][kk];

            (E->trace.get_velocity)(E,j,nelem,theta0,phi0,rad0,velocity_vector);

            x_pred=x0+velocity_vector[1]*dt;
            y_pred=y0+velocity_vector[2]*dt;
            z_pred=z0+velocity_vector[3]*dt;


            /* keep in box */

            cart_to_sphere(E,x_pred,y_pred,z_pred,&theta_pred,&phi_pred,&rad_pred);
            (E->trace.keep_within_bounds)(E,&x_pred,&y_pred,&z_pred,&theta_pred,&phi_pred,&rad_pred);

            /* Current Coordinates are always kept in positions 0-5. */

            E->trace.basicq[j][0][kk]=theta_pred;
            E->trace.basicq[j][1][kk]=phi_pred;
            E->trace.basicq[j][2][kk]=rad_pred;
            E->trace.basicq[j][3][kk]=x_pred;
            E->trace.basicq[j][4][kk]=y_pred;
            E->trace.basicq[j][5][kk]=z_pred;

            /* Fill in original coords (positions 6-8) */

            E->trace.basicq[j][6][kk]=x0;
            E->trace.basicq[j][7][kk]=y0;
            E->trace.basicq[j][8][kk]=z0;

            /* Fill in original velocities (positions 9-11) */

            E->trace.basicq[j][9][kk]=velocity_vector[1];  /* Vx */
            E->trace.basicq[j][10][kk]=velocity_vector[2];  /* Vy */
            E->trace.basicq[j][11][kk]=velocity_vector[3];  /* Vz */
//if(kk==39515 && E->parallel.me==14) fprintf(stderr,"kk=39515=> nelem=%d %lf %lf %lf Vx=%e Vy=%e Vz=%e %e %e %e\n",nelem,theta0,phi0,rad0,velocity_vector[1],velocity_vector[2],velocity_vector[3],E->trace.basicq[j][0][kk],E->trace.basicq[j][1][kk],E->trace.basicq[j][2][kk]);

        } /* end kk, predicting tracers */
    } /* end caps */

    /* find new tracer elements and caps */

    find_tracers(E);
    /* commented out MLR */
/*     for(j=1;j<=E->sphere.caps_per_proc;j++) { */
/*             theta0=E->trace.basicq[j][0][39515]; */
/*             phi0=E->trace.basicq[j][1][39515]; */
/*             rad0=E->trace.basicq[j][2][39515]; */
/*             x0=E->trace.basicq[j][3][39515]; */
/*             y0=E->trace.basicq[j][4][39515]; */
/*             z0=E->trace.basicq[j][5][39515]; */
/*             nelem=E->trace.ielement[j][39515]; */
            //if(E->parallel.me==14) fprintf(stderr,"predict_tracers:after find_tracers kk=39515 nelem=%d %lf %lf %lf\n",nelem,theta0,phi0,rad0);
	    //    }
    return;

}


/*********** CORRECT TRACERS **********************************************/
/*                                                                        */
/* This function corrects tracers using both initial and                  */
/* predicted velocities                                                   */
/*                                                                        */
/*                                                                        */
/* Note positions used in tracer array                                    */
/* [positions 0-5 are always fixed with current coordinates               */
/*  Positions 6-8 contain original Cartesian coordinates.                 */
/*  Positions 9-11 contain original Cartesian velocities.                 */
/*                                                                        */


static void correct_tracers(struct All_variables *E)
{

    int j;
    int kk;
    int nelem;


    double dt;
    double x0,y0,z0;
    double theta_pred,phi_pred,rad_pred;
    double x_pred,y_pred,z_pred;
    double theta_cor,phi_cor,rad_cor;
    double x_cor,y_cor,z_cor;
    double velocity_vector[4];
    double Vx0,Vy0,Vz0;
    double Vx_pred,Vy_pred,Vz_pred;

    void cart_to_sphere();


    dt=E->advection.timestep;


    for (j=1;j<=E->sphere.caps_per_proc;j++) {
        for (kk=1;kk<=E->trace.ntracers[j];kk++) {

            theta_pred=E->trace.basicq[j][0][kk];
            phi_pred=E->trace.basicq[j][1][kk];
            rad_pred=E->trace.basicq[j][2][kk];
            x_pred=E->trace.basicq[j][3][kk];
            y_pred=E->trace.basicq[j][4][kk];
            z_pred=E->trace.basicq[j][5][kk];

            x0=E->trace.basicq[j][6][kk];
            y0=E->trace.basicq[j][7][kk];
            z0=E->trace.basicq[j][8][kk];

            Vx0=E->trace.basicq[j][9][kk];
            Vy0=E->trace.basicq[j][10][kk];
            Vz0=E->trace.basicq[j][11][kk];

            nelem=E->trace.ielement[j][kk];

            (E->trace.get_velocity)(E,j,nelem,theta_pred,phi_pred,rad_pred,velocity_vector);

            Vx_pred=velocity_vector[1];
            Vy_pred=velocity_vector[2];
            Vz_pred=velocity_vector[3];

            x_cor=x0 + dt * 0.5*(Vx0+Vx_pred);
            y_cor=y0 + dt * 0.5*(Vy0+Vy_pred);
            z_cor=z0 + dt * 0.5*(Vz0+Vz_pred);

            cart_to_sphere(E,x_cor,y_cor,z_cor,&theta_cor,&phi_cor,&rad_cor);
            (E->trace.keep_within_bounds)(E,&x_cor,&y_cor,&z_cor,&theta_cor,&phi_cor,&rad_cor);

            /* Fill in Current Positions (other positions are no longer important) */

            E->trace.basicq[j][0][kk]=theta_cor;
            E->trace.basicq[j][1][kk]=phi_cor;
            E->trace.basicq[j][2][kk]=rad_cor;
            E->trace.basicq[j][3][kk]=x_cor;
            E->trace.basicq[j][4][kk]=y_cor;
            E->trace.basicq[j][5][kk]=z_cor;
//if(kk==39515 && E->parallel.me==14) fprintf(stderr,"kk=39515=> nelem=%d %lf %lf %lf Vx_pred=%e Vy_pred=%e Vz_pred=%e %e %e %e\n",nelem,theta_pred,phi_pred,rad_pred,Vx_pred,Vy_pred,Vz_pred,E->trace.basicq[j][0][kk],E->trace.basicq[j][1][kk],E->trace.basicq[j][2][kk]);
        } /* end kk, correcting tracers */
    } /* end caps */

    /* find new tracer elements and caps */

    find_tracers(E);
/*     for(j=1;j<=E->sphere.caps_per_proc;j++) { */
/*             theta_pred=E->trace.basicq[j][0][39515]; */
/*             phi_pred=E->trace.basicq[j][1][39515]; */
/*             rad_pred=E->trace.basicq[j][2][39515]; */
/*             x_pred=E->trace.basicq[j][3][39515]; */
/*             y_pred=E->trace.basicq[j][4][39515]; */
/*             z_pred=E->trace.basicq[j][5][39515]; */
/*             nelem=E->trace.ielement[j][39515]; */
            //if(E->parallel.me==14) fprintf(stderr,"correct_tracers:after find_tracers kk=39515 nelem=%d %lf %lf %lf\n",nelem,theta_pred,phi_pred,rad_pred);
/*     } */
    return;
}


/************ FIND TRACERS *************************************/
/*                                                             */
/* This function finds tracer elements and moves tracers to    */
/* other processor domains if necessary.                       */
/* Array ielement is filled with elemental values.                */

static void find_tracers(struct All_variables *E)
{

    int iel;
    int kk;
    int j;
    int it;
    int iprevious_element;
    int num_tracers;

    double theta,phi,rad;
    double x,y,z;
    double time_stat1;
    double time_stat2;

    void put_away_later();
    void eject_tracer();
    void reduce_tracer_arrays();
    void sphere_to_cart();
    void full_lost_souls();
    void regional_lost_souls();

    double CPU_time0();
    double begin_time = CPU_time0();


    for (j=1;j<=E->sphere.caps_per_proc;j++) {


        /* initialize arrays and statistical counters */

        E->trace.ilater[j]=E->trace.ilatersize[j]=0;

        E->trace.istat1=0;
        for (kk=0;kk<=4;kk++) {
            E->trace.istat_ichoice[j][kk]=0;
        }

        //TODO: use while-loop instead of for-loop
        /* important to index by it, not kk */

        it=0;
        num_tracers=E->trace.ntracers[j];

        for (kk=1;kk<=num_tracers;kk++) {

            it++;

            theta=E->trace.basicq[j][0][it];
            phi=E->trace.basicq[j][1][it];
            rad=E->trace.basicq[j][2][it];
            x=E->trace.basicq[j][3][it];
            y=E->trace.basicq[j][4][it];
            z=E->trace.basicq[j][5][it];

            iprevious_element=E->trace.ielement[j][it];

            iel=(E->trace.iget_element)(E,j,iprevious_element,x,y,z,theta,phi,rad);
            /* debug *
            fprintf(E->trace.fpt,"BB. kk %d %d %d %d %f %f %f %f %f %f\n",kk,j,iprevious_element,iel,x,y,z,theta,phi,rad);
            fflush(E->trace.fpt);
            */

            E->trace.ielement[j][it]=iel;

            if (iel<0) {
		fflush(E->trace.fpt);
                put_away_later(E,j,it);
                eject_tracer(E,j,it);
                it--;
            }

        } /* end tracers */

    } /* end j */


    /* Now take care of tracers that exited cap */

    /* REMOVE */
    /*
      parallel_process_termination();
    */

    if (E->parallel.nprocxy == 12)
        full_lost_souls(E);
    else
        regional_lost_souls(E);

    /* Free later arrays */

    for (j=1;j<=E->sphere.caps_per_proc;j++) {
        if (E->trace.ilatersize[j]>0) {
            for (kk=0;kk<=((E->trace.number_of_tracer_quantities)-1);kk++) {
                free(E->trace.rlater[j][kk]);
            }
        }
    } /* end j */


    /* Adjust Array Sizes */

    reduce_tracer_arrays(E);

    E->trace.find_tracers_time += CPU_time0() - begin_time;

    return;
}


/***********************************************************************/
/* This function computes the number of tracers in each element.       */
/* Each tracer can be of different "flavors", which is the 0th index   */
/* of extraq. How to interprete "flavor" is left for the application.  */

void count_tracers_of_flavors(struct All_variables *E)
{

    int j, flavor, e, kk;
    int numtracers;
    double age;

    for (j=1; j<=E->sphere.caps_per_proc; j++) {

        /* first zero arrays */
        for (flavor=0; flavor<E->trace.nflavors; flavor++)
            for (e=1; e<=E->lmesh.nel; e++) {
                E->trace.ntracer_flavor[j][flavor][e] = 0;
                E->trace.age_eltrac[j][e] = 0.0;
            }
 
        numtracers=E->trace.ntracers[j];

        /* Fill arrays */
        for (kk=1; kk<=numtracers; kk++) {
            e = E->trace.ielement[j][kk];
            flavor = E->trace.extraq[j][0][kk];
            E->trace.ntracer_flavor[j][flavor][e]++;
            
            age = E->trace.extraq[j][1][kk];
            E->trace.age_eltrac[j][e] += age;//nanzhang 2010
//if(e==1 && (E->parallel.me==1 && E->monitor.solution_cycles==2)) fprintf(stderr,"tracer_age=%.8e tracer=%d\n",E->trace.age_eltrac[j][e]-1.0e4,kk);
        }
    }

    /* debug */
    /**
    for (j=1; j<=E->sphere.caps_per_proc; j++) {
        for (e=1; e<=E->lmesh.nel; e++) {
            fprintf(E->trace.fpt, "element=%d ntracer_flaver =", e);
            for (flavor=0; flavor<E->trace.nflavors; flavor++) {
                fprintf(E->trace.fpt, " %d",
                        E->trace.ntracer_flavor[j][flavor][e]);
            }
            fprintf(E->trace.fpt, "\n");
        }
    }
    fflush(E->trace.fpt);
    /**/

    return;
}



void initialize_tracers(struct All_variables *E)
{

    if (E->trace.ic_method==0)
        make_tracer_array(E);
    else if (E->trace.ic_method==1)
        read_tracer_file(E);
    else if (E->trace.ic_method==2)
        read_old_tracer_file(E);
    else {
        fprintf(E->trace.fpt,"Not ready for other inputs yet\n");
        fflush(E->trace.fpt);
        parallel_process_termination();
    }


    /* total number of tracers  */

    E->trace.ilast_tracer_count = isum_tracers(E);
    fprintf(E->trace.fpt, "Sum of Tracers: %d\n", E->trace.ilast_tracer_count);
    if(E->parallel.me==0)
        fprintf(stderr, "Sum of Tracers: %d\n", E->trace.ilast_tracer_count);


    /* find elements */

    find_tracers(E);


    /* count # of tracers of each flavor */

    if (E->trace.nflavors > 0)
        count_tracers_of_flavors(E);

    return;
}


/************** MAKE TRACER ARRAY ********************************/
/* Here, each processor will generate tracers somewhere          */
/* in the sphere - check if its in this cap  - then check radial */

static void make_tracer_array(struct All_variables *E)
{

    int tracers_cap;
    int j;
    double processor_fraction;

    void generate_random_tracers();
    void init_tracer_flavors();

    if (E->parallel.me==0) fprintf(stderr,"Making Tracer Array\n");

    for (j=1;j<=E->sphere.caps_per_proc;j++) {

        processor_fraction=E->lmesh.volume/E->mesh.volume;
        tracers_cap=E->mesh.nel*E->trace.itperel*processor_fraction;
        /*
          fprintf(stderr,"AA: proc frac: %f (%d) %d %d %f %f\n",processor_fraction,tracers_cap,E->lmesh.nel,E->parallel.nprocz, E->sx[j][3][E->lmesh.noz],E->sx[j][3][1]);
        */

        fprintf(E->trace.fpt,"\nGenerating %d Tracers\n",tracers_cap);

        generate_random_tracers(E, tracers_cap, j);



    }/* end j */


    /* Initialize tracer flavors */
    if (E->trace.nflavors) init_tracer_flavors(E);

    return;
}



static void generate_random_tracers(struct All_variables *E,
                                    int tracers_cap, int j)
{
    void cart_to_sphere();
    int kk;
    int ival;
    int number_of_tries=0;
    int max_tries;

    double x,y,z;
    double theta,phi,rad;
    double xmin,xmax,ymin,ymax,zmin,zmax;
    double random1,random2,random3;


    allocate_tracer_arrays(E,j,tracers_cap);

    /* Finding the min/max of the cartesian coordinates. */
    /* One must loop over E->X to find the min/max, since the 8 corner */
    /* nodes may not be the min/max. */
    xmin = ymin = zmin = E->sphere.ro;
    xmax = ymax = zmax = -E->sphere.ro;
    for (kk=1; kk<=E->lmesh.nno; kk++) {
        x = E->x[j][1][kk];
        y = E->x[j][2][kk];
        z = E->x[j][3][kk];

        xmin = ((xmin < x) ? xmin : x);
        xmax = ((xmax > x) ? xmax : x);
        ymin = ((ymin < y) ? ymin : y);
        ymax = ((ymax > y) ? ymax : y);
        zmin = ((zmin < z) ? zmin : z);
        zmax = ((zmax > z) ? zmax : z);
    }

    /* Tracers are placed randomly in cap */
    /* (intentionally using rand() instead of srand() )*/

    while (E->trace.ntracers[j]<tracers_cap) {

        number_of_tries++;
        max_tries=100*tracers_cap;

        if (number_of_tries>max_tries) {
            fprintf(E->trace.fpt,"Error(make_tracer_array)-too many tries?\n");
            fprintf(E->trace.fpt,"%d %d %d\n",max_tries,number_of_tries,RAND_MAX);
            fflush(E->trace.fpt);
            exit(10);
        }

#if 1
        random1=drand48();
        random2=drand48();
        random3=drand48();
#else
        random1=(1.0*rand())/(1.0*RAND_MAX);
        random2=(1.0*rand())/(1.0*RAND_MAX);
        random3=(1.0*rand())/(1.0*RAND_MAX);
#endif

        x=xmin+random1*(xmax-xmin);
        y=ymin+random2*(ymax-ymin);
        z=zmin+random3*(zmax-zmin);

        /* first check if within shell */

        cart_to_sphere(E,x,y,z,&theta,&phi,&rad);

        if (rad>=E->sx[j][3][E->lmesh.noz]) continue;
        if (rad<E->sx[j][3][1]) continue;


        /* check if in current cap */
        if (E->parallel.nprocxy==1)
            ival=regional_icheck_cap(E,0,theta,phi,rad,rad);
        else
            ival=full_icheck_cap(E,0,x,y,z,rad);

        if (ival!=1) continue;

        /* Made it, so record tracer information */

        (E->trace.keep_within_bounds)(E,&x,&y,&z,&theta,&phi,&rad);

        E->trace.ntracers[j]++;
        kk=E->trace.ntracers[j];

        E->trace.basicq[j][0][kk]=theta;
        E->trace.basicq[j][1][kk]=phi;
        E->trace.basicq[j][2][kk]=rad;
        E->trace.basicq[j][3][kk]=x;
        E->trace.basicq[j][4][kk]=y;
        E->trace.basicq[j][5][kk]=z;

    } /* end while */

    return;
}


/******** READ TRACER ARRAY *********************************************/
/*                                                                      */
/* This function reads tracers from input file.                         */
/* All processors read the same input file, then sort out which ones    */
/* belong.                                                              */

static void read_tracer_file(struct All_variables *E)
{

    char input_s[1000];

    int number_of_tracers, ncolumns;
    int kk;
    int icheck;
    int iestimate;
    int icushion;
    int i, j;


    int icheck_processor_shell();
    void sphere_to_cart();
    void cart_to_sphere();
    void expand_tracer_arrays();

    double x,y,z;
    double theta,phi,rad;
    double buffer[100];

    FILE *fptracer;

    fptracer=fopen(E->trace.tracer_file,"r");

    fgets(input_s,200,fptracer);
    if(sscanf(input_s,"%d %d",&number_of_tracers,&ncolumns) != 2) {
        fprintf(stderr,"Error while reading file '%s'\n", E->trace.tracer_file);
        exit(8);
    }
    fprintf(E->trace.fpt,"%d Tracers, %d columns in file \n",
            number_of_tracers, ncolumns);

    /* some error control */
    if (E->trace.number_of_extra_quantities+3 != ncolumns) {
        fprintf(E->trace.fpt,"ERROR(read tracer file)-wrong # of columns\n");
        fflush(E->trace.fpt);
        exit(10);
    }


    /* initially size tracer arrays to number of tracers divided by processors */

    icushion=100;

    iestimate=number_of_tracers/E->parallel.nproc + icushion;

    for (j=1;j<=E->sphere.caps_per_proc;j++) {

        allocate_tracer_arrays(E,j,iestimate);

        for (kk=1;kk<=number_of_tracers;kk++) {
            int len, ncol;
            ncol = 3 + E->trace.number_of_extra_quantities;

            len = read_double_vector(fptracer, ncol, buffer);
            if (len != ncol) {
                fprintf(E->trace.fpt,"ERROR(read tracer file) - wrong input file format: %s\n", E->trace.tracer_file);
                fflush(E->trace.fpt);
                exit(10);
            }

            theta = buffer[0];
            phi = buffer[1];
            rad = buffer[2];

            sphere_to_cart(E,theta,phi,rad,&x,&y,&z);


            /* make sure theta, phi is in range, and radius is within bounds */

            (E->trace.keep_within_bounds)(E,&x,&y,&z,&theta,&phi,&rad);

            /* check whether tracer is within processor domain */

            icheck=1;
            if (E->parallel.nprocz>1) icheck=icheck_processor_shell(E,j,rad);
            if (icheck!=1) continue;

            if (E->parallel.nprocxy==1)
                icheck=regional_icheck_cap(E,0,theta,phi,rad,rad);
            else
                icheck=full_icheck_cap(E,0,x,y,z,rad);

            if (icheck==0) continue;

            /* if still here, tracer is in processor domain */


            E->trace.ntracers[j]++;

            if (E->trace.ntracers[j]>=(E->trace.max_ntracers[j]-5)) expand_tracer_arrays(E,j);

            E->trace.basicq[j][0][E->trace.ntracers[j]]=theta;
            E->trace.basicq[j][1][E->trace.ntracers[j]]=phi;
            E->trace.basicq[j][2][E->trace.ntracers[j]]=rad;
            E->trace.basicq[j][3][E->trace.ntracers[j]]=x;
            E->trace.basicq[j][4][E->trace.ntracers[j]]=y;
            E->trace.basicq[j][5][E->trace.ntracers[j]]=z;

            for (i=0; i<E->trace.number_of_extra_quantities; i++)
                E->trace.extraq[j][i][E->trace.ntracers[j]]=buffer[i+3];

        } /* end kk, number of tracers */

        fprintf(E->trace.fpt,"Number of tracers in this cap is: %d\n",
                E->trace.ntracers[j]);

        /** debug **
        for (kk=1; kk<=E->trace.ntracers[j]; kk++) {
            fprintf(E->trace.fpt, "tracer#=%d sph_coord=(%g,%g,%g)", kk,
                    E->trace.basicq[j][0][kk],
                    E->trace.basicq[j][1][kk],
                    E->trace.basicq[j][2][kk]);
            fprintf(E->trace.fpt, "   extraq=");
            for (i=0; i<E->trace.number_of_extra_quantities; i++)
                fprintf(E->trace.fpt, " %g", E->trace.extraq[j][i][kk]);
            fprintf(E->trace.fpt, "\n");
        }
        fflush(E->trace.fpt);
        /**/

    } /* end j */

    fclose(fptracer);

    icheck=isum_tracers(E);

    if (icheck!=number_of_tracers) {
        fprintf(E->trace.fpt,"ERROR(read_tracer_file) - tracers != number in file\n");
        fprintf(E->trace.fpt,"Tracers in system: %d\n", icheck);
        fprintf(E->trace.fpt,"Tracers in file: %d\n", number_of_tracers);
        fflush(E->trace.fpt);
        exit(10);
    }

    return;
}


/************** READ OLD TRACER FILE *************************************/
/*                                                                       */
/* This function read tracers written from previous calculation          */
/* and the tracers are read as seperate files for each processor domain. */

static void read_old_tracer_file(struct All_variables *E)
{

    char output_file[200];
    char input_s[1000];

    int i,j,kk,rezip;
    int idum1,ncolumns;
    int numtracers;

    double rdum1;
    double theta,phi,rad;
    double x,y,z;
    double buffer[100];

    void sphere_to_cart();

    FILE *fp1;

    if (E->trace.number_of_extra_quantities>99) {
        fprintf(E->trace.fpt,"ERROR(read_old_tracer_file)-increase size of extra[]\n");
        fflush(E->trace.fpt);
        parallel_process_termination();
    }



    /* deal with different output formats */
/*
#ifdef USE_GZDIR
    if(strcmp(E->output.format, "ascii-gz") == 0){
      sprintf(output_file,"%s/%d/tracer.%d.%d",
	      E->control.data_dir_old,E->monitor.solution_cycles_init,E->parallel.me,E->monitor.solution_cycles_init);
      rezip = open_file_zipped(output_file,&fp1,E);
    }else{
      sprintf(output_file,"%s.tracer.%d.%d",E->control.old_P_file,E->parallel.me,E->monitor.solution_cycles_init);
      if ( (fp1=fopen(output_file,"r"))==NULL) {
        fprintf(E->trace.fpt,"ERROR(read_old_tracer_file)-gziped file not found %s\n",output_file);
        fflush(E->trace.fpt);
        exit(10);
      }
    }
#else
*/
    //sprintf(output_file,"%s.tracer.%d.%d",E->control.old_P_file,E->parallel.me,E->monitor.solution_cycles_init);
    sprintf(output_file,"%s/a.tracers.%d.%d",E->control.data_dir_old,E->parallel.me,E->monitor.solution_cycles_init);
    if ( (fp1=fopen(output_file,"r"))==NULL) {
        fprintf(stderr,"ERROR(read_old_tracer_file)-file not found %s\n",output_file);
	terminate();
    }
//#endif

    fprintf(stderr,"Read old tracers from %s\n",output_file);


    for(j=1;j<=E->sphere.caps_per_proc;j++) {
        fgets(input_s,200,fp1);
        if(sscanf(input_s,"%d %d %d %lf",
                  &idum1, &numtracers, &ncolumns, &rdum1) != 4) {
            fprintf(stderr,"Error while reading file '%s'\n", output_file);
            exit(8);
        }


        /* some error control */
        if (E->trace.number_of_extra_quantities+3 != ncolumns) {
            fprintf(E->trace.fpt,"ERROR(read_old_tracer_file)-wrong # of columns\n");
            fflush(E->trace.fpt);
            exit(10);
        }

        /* allocate memory for tracer arrays */

        allocate_tracer_arrays(E,j,numtracers);
        E->trace.ntracers[j]=numtracers;

        for (kk=1;kk<=numtracers;kk++) {
            int len, ncol;
            ncol = 3 + E->trace.number_of_extra_quantities;

            len = read_double_vector(fp1, ncol, buffer);
            if (len != ncol) {
                fprintf(E->trace.fpt,"ERROR(read_old_tracer_file) - wrong input file format: %s\n", output_file);
                fflush(E->trace.fpt);
                exit(10);
            }

            theta = buffer[0];
            phi = buffer[1];
            rad = buffer[2];

            sphere_to_cart(E,theta,phi,rad,&x,&y,&z);

            /* it is possible that if on phi=0 boundary, significant digits can push phi over 2pi */

            (E->trace.keep_within_bounds)(E,&x,&y,&z,&theta,&phi,&rad);

            E->trace.basicq[j][0][kk]=theta;
            E->trace.basicq[j][1][kk]=phi;
            E->trace.basicq[j][2][kk]=rad;
            E->trace.basicq[j][3][kk]=x;
            E->trace.basicq[j][4][kk]=y;
            E->trace.basicq[j][5][kk]=z;

            for (i=0; i<E->trace.number_of_extra_quantities; i++)
                E->trace.extraq[j][i][kk]=buffer[i+3];

        }

        /** debug **
        for (kk=1; kk<=E->trace.ntracers[j]; kk++) {
            fprintf(E->trace.fpt, "tracer#=%d sph_coord=(%g,%g,%g)", kk,
                    E->trace.basicq[j][0][kk],
                    E->trace.basicq[j][1][kk],
                    E->trace.basicq[j][2][kk]);
            fprintf(E->trace.fpt, "   extraq=");
            for (i=0; i<E->trace.number_of_extra_quantities; i++)
                fprintf(E->trace.fpt, " %g", E->trace.extraq[j][i][kk]);
            fprintf(E->trace.fpt, "\n");
        }
        fflush(E->trace.fpt);
        /**/

        fprintf(stderr,"Read %d tracers from file %s\n",numtracers,output_file);

    }
    fclose(fp1);
/*
#ifdef USE_GZDIR
    if(strcmp(E->output.format, "ascii-gz") == 0)
      if(rezip)	
	gzip_file(output_file);
#endif
*/

    return;
}





/*********** CHECK SUM **************************************************/
/*                                                                      */
/* This functions checks to make sure number of tracers is preserved    */

static void check_sum(struct All_variables *E)
{

    int number, iold_number;

    number = isum_tracers(E);

    iold_number = E->trace.ilast_tracer_count;

    if (number != iold_number) {
        fprintf(E->trace.fpt,"ERROR(check_sum)-break in conservation %d %d\n",
                number,iold_number);
        fflush(E->trace.fpt);
        if (E->trace.itracer_warnings)
            parallel_process_termination();
    }

    E->trace.ilast_tracer_count = number;

    return;
}


/************* ISUM TRACERS **********************************************/
/*                                                                       */
/* This function uses MPI to sum all tracers and returns number of them. */

static int isum_tracers(struct All_variables *E)
{
    int imycount;
    int iallcount;
    int j;

    iallcount = 0;

    imycount = 0;
    for (j=1; j<=E->sphere.caps_per_proc; j++)
        imycount = imycount + E->trace.ntracers[j];

    MPI_Allreduce(&imycount,&iallcount,1,MPI_INT,MPI_SUM,E->parallel.world);

    return iallcount;
}



/********** CART TO SPHERE ***********************/
void cart_to_sphere(struct All_variables *E,
                    double x, double y, double z,
                    double *theta, double *phi, double *rad)
{

    double temp;
    double myatan();

    temp=x*x+y*y;

    *rad=sqrt(temp+z*z);
    *theta=atan2(sqrt(temp),z);
    *phi=myatan(y,x);


    return;
}

/********** SPHERE TO CART ***********************/
void sphere_to_cart(struct All_variables *E,
                    double theta, double phi, double rad,
                    double *x, double *y, double *z)
{

    double sint,cost,sinf,cosf;
    double temp;

    sint=sin(theta);
    cost=cos(theta);
    sinf=sin(phi);
    cosf=cos(phi);

    temp=rad*sint;

    *x=temp*cosf;
    *y=temp*sinf;
    *z=rad*cost;

    return;
}



static void init_tracer_flavors(struct All_variables *E)
{
    int j, kk, number_of_tracers;
    int i;
    double flavor;
	double theta,phi,rad;
	double x0,y0,z0,x1,y1,z1;
	double distance;
 
    switch(E->trace.ic_method_for_flavors){
    case 0:
      /* ic_method_for_flavors == 0 (layered structure) */
      /* any tracer above z_interface[i] is of flavor i */
      /* any tracer below z_interface is of flavor (nflavors-1) */
      for (j=1;j<=E->sphere.caps_per_proc;j++) {

	number_of_tracers = E->trace.ntracers[j];
	for (kk=1;kk<=number_of_tracers;kk++) {
	  rad = E->trace.basicq[j][2][kk];

          flavor = E->trace.nflavors - 1;
          for (i=0; i<E->trace.nflavors-1; i++) {
              if (rad > E->trace.z_interface[i]) {
                  flavor = i;
                  break;
              }
          }
          E->trace.extraq[j][0][kk] = flavor;
         
          E->trace.extraq[j][1][kk] = 0.0;
	}
      }
      break;

    case 1:

	for (j=1;j<=E->sphere.caps_per_proc;j++) 
	{
		number_of_tracers = E->trace.ntracers[j];
		for (kk=1;kk<=number_of_tracers;kk++) 
		{
			theta = E->trace.basicq[j][0][kk];
			phi = E->trace.basicq[j][1][kk];
			rad = E->trace.basicq[j][2][kk];
			if(rad<0.96861)
			{
				flavor = 0;
			}
			else
			{
            			sphere_to_cart(E,theta,phi,rad,&x1,&y1,&z1);
				flavor = 0;
				for (i=0; i<E->trace.number_of_continents; i++) 
				{
            				sphere_to_cart(E,E->trace.lat_of_continents[i],E->trace.lon_of_continents[i],rad,&x0,&y0,&z0);
					distance=sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)+(z1-z0)*(z1-z0));			
					distance=distance/rad;
					if(distance<E->trace.radius_of_continents[i])	
					{
						flavor=1;
						break;
					}
				}
			}
			E->trace.extraq[j][0][kk] = flavor;
			E->trace.extraq[j][1][kk] = 0.0;
		}
	}
	break;
    case 2:
	add_layered_composition(E);
	if(E->trace.number_of_continents>0)
	{
		add_continents(E);
	}
	break;

    case 99:			/* (will override restart) */
#ifndef USE_GGRD
      fprintf(stderr,"ic_method_for_flavors %i requires the ggrd routines from hc, -DUSE_GGRD\n",
	      E->trace.ic_method_for_flavors);
      parallel_process_termination();
#else
      ggrd_init_tracer_flavors(E);
#endif
      break;


    default:

      fprintf(stderr,"ic_method_for_flavors %i undefined\n",E->trace.ic_method_for_flavors);
      parallel_process_termination();
      break;
    }


    return;
}


/******************* get_neighboring_caps ************************************/
/*                                                                           */
/* Communicate with neighboring processors to get their cap boundaries,      */
/* which is later used by (E->trace.icheck_cap)()                            */
/*                                                                           */

void get_neighboring_caps(struct All_variables *E)
{
    void sphere_to_cart();

    const int ncorners = 4; /* # of top corner nodes */
    int i, j, n, d, kk, lev, idb;
    int num_ngb, neighbor_proc, tag;
    MPI_Status status[200];
    MPI_Request request[200];

    int node[ncorners];
    double xx[ncorners*2], rr[12][ncorners*2];
    int nox,noy,noz;
    double x,y,z;
    double theta,phi,rad;

    nox=E->lmesh.nox;
    noy=E->lmesh.noy;
    noz=E->lmesh.noz;

    node[0]=nox*noz*(noy-1)+noz;
    node[1]=noz;
    node[2]=noz*nox;
    node[3]=noz*nox*noy;

    lev = E->mesh.levmax;
    tag = 45;

    for (j=1; j<=E->sphere.caps_per_proc; j++) {

        /* loop over top corners to get their coordinates */
        n = 0;
        for (i=0; i<ncorners; i++) {
            for (d=0; d<2; d++) {
                xx[n] = E->sx[j][d+1][node[i]];
                n++;
            }
        }

        idb = 0;
        num_ngb = E->parallel.TNUM_PASS[lev][j];
        for (kk=1; kk<=num_ngb; kk++) {
            neighbor_proc = E->parallel.PROCESSOR[lev][j].pass[kk];

            MPI_Isend(xx, n, MPI_DOUBLE, neighbor_proc,
                      tag, E->parallel.world, &request[idb]);
            idb++;

            MPI_Irecv(rr[kk], n, MPI_DOUBLE, neighbor_proc,
                      tag, E->parallel.world, &request[idb]);
            idb++;
        }

        /* Storing the current cap information */
        for (i=0; i<n; i++)
            rr[0][i] = xx[i];

        /* Wait for non-blocking calls to complete */

        MPI_Waitall(idb, request, status);

        /* Storing the received cap information
         * XXX: this part assumes:
         *      1) E->sphere.caps_per_proc==1
         *      2) E->mesh.nsd==3
         */
        for (kk=0; kk<=num_ngb; kk++) {
            n = 0;
            for (i=1; i<=ncorners; i++) {
                theta = rr[kk][n++];
                phi = rr[kk][n++];
                rad = E->sphere.ro;

                sphere_to_cart(E, theta, phi, rad, &x, &y, &z);

                E->trace.xcap[kk][i] = x;
                E->trace.ycap[kk][i] = y;
                E->trace.zcap[kk][i] = z;
                E->trace.theta_cap[kk][i] = theta;
                E->trace.phi_cap[kk][i] = phi;
                E->trace.rad_cap[kk][i] = rad;
                E->trace.cos_theta[kk][i] = cos(theta);
                E->trace.sin_theta[kk][i] = sin(theta);
                E->trace.cos_phi[kk][i] = cos(phi);
                E->trace.sin_phi[kk][i] = sin(phi);
            }
        } /* end kk, number of neighbors */

        /* debugging output *
        for (kk=0; kk<=num_ngb; kk++) {
            if (kk==0)
                neighbor_proc = E->parallel.me;
            else
                neighbor_proc = E->parallel.PROCESSOR[lev][1].pass[kk];

            for (i=1; i<=ncorners; i++) {
                fprintf(E->trace.fpt, "pass=%d rank=%d corner=%d "
                        "sx=(%g, %g, %g)\n",
                        kk, neighbor_proc, i,
                        E->trace.theta_cap[kk][i],
                        E->trace.phi_cap[kk][i],
                        E->trace.rad_cap[kk][i]);
            }
        }
        fflush(E->trace.fpt);
        /**/
    }

    return;
}


/**************** INITIALIZE TRACER ARRAYS ************************************/
/*                                                                            */
/* This function allocates memories to tracer arrays.                         */

void allocate_tracer_arrays(struct All_variables *E,
                            int j, int number_of_tracers)
{

    int kk;

    /* max_ntracers is physical size of tracer array */
    /* (initially make it 25% larger than required */

    E->trace.max_ntracers[j]=number_of_tracers+number_of_tracers/4;
    E->trace.ntracers[j]=0;

    /* make tracer arrays */

    if ((E->trace.ielement[j]=(int *) malloc(E->trace.max_ntracers[j]*sizeof(int)))==NULL) {
        fprintf(E->trace.fpt,"ERROR(make tracer array)-no memory 1a\n");
        fflush(E->trace.fpt);
        exit(10);
    }
    for (kk=1;kk<E->trace.max_ntracers[j];kk++)
        E->trace.ielement[j][kk]=-99;


    for (kk=0;kk<E->trace.number_of_basic_quantities;kk++) {
        if ((E->trace.basicq[j][kk]=(double *)malloc(E->trace.max_ntracers[j]*sizeof(double)))==NULL) {
            fprintf(E->trace.fpt,"ERROR(initialize tracer arrays)-no memory 1b.%d\n",kk);
            fflush(E->trace.fpt);
            exit(10);
        }
    }

    for (kk=0;kk<E->trace.number_of_extra_quantities;kk++) {
        if ((E->trace.extraq[j][kk]=(double *)malloc(E->trace.max_ntracers[j]*sizeof(double)))==NULL) {
            fprintf(E->trace.fpt,"ERROR(initialize tracer arrays)-no memory 1c.%d\n",kk);
            fflush(E->trace.fpt);
            exit(10);
        }
    }

    if (E->trace.nflavors > 0) {
        E->trace.ntracer_flavor[j]=(int **)malloc(E->trace.nflavors*sizeof(int*));
        E->trace.age_eltrac[j]=(double *)malloc((E->lmesh.nel+1)*sizeof(double));//nanzhang 2010
        E->trace.age_el[j]=(double *)malloc((E->lmesh.nel+1)*sizeof(double)); 
        E->trace.age_node[j]=(double *)malloc((E->lmesh.nno+1)*sizeof(double));
        for (kk=0;kk<E->trace.nflavors;kk++) {
            if ((E->trace.ntracer_flavor[j][kk]=(int *)malloc((E->lmesh.nel+1)*sizeof(int)))==NULL) {
                fprintf(E->trace.fpt,"ERROR(initialize tracer arrays)-no memory 1c.%d\n",kk);
                fflush(E->trace.fpt);
                exit(10);
            }
        }
    }


    fprintf(E->trace.fpt,"Physical size of tracer arrays (max_ntracers): %d\n",
            E->trace.max_ntracers[j]);
    fflush(E->trace.fpt);

    return;
}



/****** EXPAND TRACER ARRAYS *****************************************/

void expand_tracer_arrays(struct All_variables *E, int j)
{

    int inewsize;
    int kk;
    int icushion;

    /* expand basicq and ielement by 20% */

    icushion=100;

    inewsize=E->trace.max_ntracers[j]+E->trace.max_ntracers[j]/5+icushion;

    if ((E->trace.ielement[j]=(int *)realloc(E->trace.ielement[j],inewsize*sizeof(int)))==NULL) {
        fprintf(E->trace.fpt,"ERROR(expand tracer arrays )-no memory (ielement)\n");
        fflush(E->trace.fpt);
        exit(10);
    }

    for (kk=0;kk<=((E->trace.number_of_basic_quantities)-1);kk++) {
        if ((E->trace.basicq[j][kk]=(double *)realloc(E->trace.basicq[j][kk],inewsize*sizeof(double)))==NULL) {
            fprintf(E->trace.fpt,"ERROR(expand tracer arrays )-no memory (%d)\n",kk);
            fflush(E->trace.fpt);
            exit(10);
        }
    }

    for (kk=0;kk<=((E->trace.number_of_extra_quantities)-1);kk++) {
        if ((E->trace.extraq[j][kk]=(double *)realloc(E->trace.extraq[j][kk],inewsize*sizeof(double)))==NULL) {
            fprintf(E->trace.fpt,"ERROR(expand tracer arrays )-no memory 78 (%d)\n",kk);
            fflush(E->trace.fpt);
            exit(10);
        }
    }


    fprintf(E->trace.fpt,"Expanding physical memory of ielement, basicq, and extraq to %d from %d\n",
            inewsize,E->trace.max_ntracers[j]);

    E->trace.max_ntracers[j]=inewsize;

    return;
}




/****** REDUCE  TRACER ARRAYS *****************************************/

static void reduce_tracer_arrays(struct All_variables *E)
{

    int inewsize;
    int kk;
    int iempty_space;
    int j;

    int icushion=100;

    for (j=1;j<=E->sphere.caps_per_proc;j++) {


        /* if physical size is double tracer size, reduce it */

        iempty_space=(E->trace.max_ntracers[j]-E->trace.ntracers[j]);

        if (iempty_space>(E->trace.ntracers[j]+icushion)) {


            inewsize=E->trace.ntracers[j]+E->trace.ntracers[j]/4+icushion;

            if (inewsize<1) {
                fprintf(E->trace.fpt,"Error(reduce tracer arrays)-something up (hdf3)\n");
                fflush(E->trace.fpt);
                exit(10);
            }


            if ((E->trace.ielement[j]=(int *)realloc(E->trace.ielement[j],inewsize*sizeof(int)))==NULL) {
                fprintf(E->trace.fpt,"ERROR(reduce tracer arrays )-no memory (ielement)\n");
                fflush(E->trace.fpt);
                exit(10);
            }


            for (kk=0;kk<=((E->trace.number_of_basic_quantities)-1);kk++) {
                if ((E->trace.basicq[j][kk]=(double *)realloc(E->trace.basicq[j][kk],inewsize*sizeof(double)))==NULL) {
                    fprintf(E->trace.fpt,"AKM(reduce tracer arrays )-no memory (%d)\n",kk);
                    fflush(E->trace.fpt);
                    exit(10);
                }
            }

            for (kk=0;kk<=((E->trace.number_of_extra_quantities)-1);kk++) {
                if ((E->trace.extraq[j][kk]=(double *)realloc(E->trace.extraq[j][kk],inewsize*sizeof(double)))==NULL) {
                    fprintf(E->trace.fpt,"AKM(reduce tracer arrays )-no memory 783 (%d)\n",kk);
                    fflush(E->trace.fpt);
                    exit(10);
                }
            }


            fprintf(E->trace.fpt,"Reducing physical memory of ielement, basicq, and extraq to %d from %d\n",
                    E->trace.max_ntracers[j],inewsize);

            E->trace.max_ntracers[j]=inewsize;

        } /* end if */

    } /* end j */

    return;
}


/********** PUT AWAY LATER ************************************/
/*                                             */
/* rlater has a similar structure to basicq     */
/* ilatersize is the physical memory and       */
/* ilater is the number of tracers             */

static void put_away_later(struct All_variables *E, int j, int it)
{
    int kk;
    void expand_later_array();


    /* The first tracer in initiates memory allocation. */
    /* Memory is freed after parallel communications    */

    if (E->trace.ilatersize[j]==0) {

        E->trace.ilatersize[j]=E->trace.max_ntracers[j]/5;

        for (kk=0;kk<=((E->trace.number_of_tracer_quantities)-1);kk++) {
            if ((E->trace.rlater[j][kk]=(double *)malloc(E->trace.ilatersize[j]*sizeof(double)))==NULL) {
                fprintf(E->trace.fpt,"AKM(put_away_later)-no memory (%d)\n",kk);
                fflush(E->trace.fpt);
                exit(10);
            }
        }
    } /* end first particle initiating memory allocation */


    /* Put tracer in later array */

    E->trace.ilater[j]++;

    if (E->trace.ilater[j] >= (E->trace.ilatersize[j]-5)) expand_later_array(E,j);

    /* stack basic and extra quantities together (basic first) */

    for (kk=0;kk<=((E->trace.number_of_basic_quantities)-1);kk++)
        E->trace.rlater[j][kk][E->trace.ilater[j]]=E->trace.basicq[j][kk][it];

    for (kk=0;kk<=((E->trace.number_of_extra_quantities)-1);kk++)
        E->trace.rlater[j][E->trace.number_of_basic_quantities+kk][E->trace.ilater[j]]=E->trace.extraq[j][kk][it];


    return;
}


/****** EXPAND LATER ARRAY *****************************************/

void expand_later_array(struct All_variables *E, int j)
{

    int inewsize;
    int kk;
    int icushion;

    /* expand rlater by 20% */

    icushion=100;

    inewsize=E->trace.ilatersize[j]+E->trace.ilatersize[j]/5+icushion;

    for (kk=0;kk<=((E->trace.number_of_tracer_quantities)-1);kk++) {
        if ((E->trace.rlater[j][kk]=(double *)realloc(E->trace.rlater[j][kk],inewsize*sizeof(double)))==NULL) {
            fprintf(E->trace.fpt,"AKM(expand later array )-no memory (%d)\n",kk);
            fflush(E->trace.fpt);
            exit(10);
        }
    }


    fprintf(E->trace.fpt,"Expanding physical memory of rlater to %d from %d\n",
            inewsize,E->trace.ilatersize[j]);

    E->trace.ilatersize[j]=inewsize;

    return;
}


/***** EJECT TRACER ************************************************/

static void eject_tracer(struct All_variables *E, int j, int it)
{

    int ilast_tracer;
    int kk;


    ilast_tracer=E->trace.ntracers[j];

    /* put last tracer in ejected tracer position */

    E->trace.ielement[j][it]=E->trace.ielement[j][ilast_tracer];

    for (kk=0;kk<=((E->trace.number_of_basic_quantities)-1);kk++)
        E->trace.basicq[j][kk][it]=E->trace.basicq[j][kk][ilast_tracer];

    for (kk=0;kk<=((E->trace.number_of_extra_quantities)-1);kk++)
        E->trace.extraq[j][kk][it]=E->trace.extraq[j][kk][ilast_tracer];



    E->trace.ntracers[j]--;

    return;
}



/********** ICHECK PROCESSOR SHELL *************/
/* returns -99 if rad is below current shell  */
/* returns 0 if rad is above current shell    */
/* returns 1 if rad is within current shell   */
/*                                            */
/* Shell, here, refers to processor shell     */
/*                                            */
/* shell is defined as bottom boundary up to  */
/* and not including the top boundary unless  */
/* the shell in question is the top shell     */

int icheck_processor_shell(struct All_variables *E,
                           int j, double rad)
{

    const int noz = E->lmesh.noz;
    const int nprocz = E->parallel.nprocz;
    double top_r, bottom_r;

    if (nprocz==1) return 1;

    top_r = E->sx[j][3][noz];
    bottom_r = E->sx[j][3][1];

    /* First check bottom */

    if (rad<bottom_r) return -99;


    /* Check top */

    if (rad<top_r) return 1;

    /* top processor */

    if ( (rad<=top_r) && (E->parallel.me_loc[3]==nprocz-1) ) return 1;

    /* If here, means point is above processor */
    return 0;
}


/********* ICHECK THAT PROCESSOR SHELL ********/
/*                                            */
/* Checks whether a given radius is within    */
/* a given processors radial domain.          */
/* Returns 0 if not, 1 if so.                 */
/* The domain is defined as including the bottom */
/* radius, but excluding the top radius unless   */
/* we the processor domain is the one that       */
/* is at the surface (then both boundaries are   */
/* included).                                    */

int icheck_that_processor_shell(struct All_variables *E,
                                int j, int nprocessor, double rad)
{
    int icheck_processor_shell();
    int me = E->parallel.me;

    /* nprocessor is right on top of me */
    if (nprocessor == me+1) {
        if (icheck_processor_shell(E, j, rad) == 0) return 1;
        else return 0;
    }

    /* nprocessor is right on bottom of me */
    if (nprocessor == me-1) {
        if (icheck_processor_shell(E, j, rad) == -99) return 1;
        else return 0;
    }

    /* Shouldn't be here */
    fprintf(E->trace.fpt, "Should not be here\n");
    fprintf(E->trace.fpt, "Error(check_shell) nprocessor: %d, radius: %f\n",
            nprocessor, rad);
    fflush(E->trace.fpt);
    exit(10);

    return 0;
}

//update the age for each tracer
void update_age(E)
   struct All_variables *E;
{
    int i,j,kk,size1;
    int numOC,totalNumOC;
    double *temp_tracer1[13],*temp_theta[13],*temp_phi[13],*temp_rad[13];
    double rad,z_ocean_crust;
    char output_file[200];
    FILE *fpOutput;
    int file_ID;
	static int been_here1=0;
	static int been_here=0;

    double time_scale=1.288e6;//convert to Ma
	FILE *fp;
	char tempstring[256];
	int element;

	if(E->control.make_crust!=0 && been_here1==0)
	{
		fprintf(stderr,"Warning: make crust and updata age do not match\n");
		been_here1++;
//                parallel_process_termination();
	}
	if(been_here==0 && E->control.restart==0 && E->trace.ic_method!=2)
	{
		if(E->parallel.me==0)
			fprintf(stderr,"read element age from file\n");
		  if(E->read_element_age !=0)
		  {
			snprintf(tempstring,255,"%s/age.%d.%d",E->control.data_dir,E->parallel.me,E->read_element_age);
			fp=fopen(tempstring,"rb");
			fread(E->age,sizeof(double),E->lmesh.nel+1,fp);
			fclose(fp);
			for(element=1;element<=E->lmesh.nel;element++)
			{
				E->old_age[element]=E->age[element];
			}
		  }
	
		for (j=1;j<=E->sphere.caps_per_proc;j++) 
		{
			for (kk=1;kk<=E->trace.ntracers[j];kk++) 
			{
				element=E->trace.ielement[j][kk];
				E->trace.extraq[j][1][kk] = E->age[element]+ E->advection.timestep*time_scale;
			}
		}
		been_here++;
		printf("111111111111111111111111111\n");
	}
	else
	{
		for (j=1;j<=E->sphere.caps_per_proc;j++) 
		{
			for (kk=1;kk<=E->trace.ntracers[j];kk++) 
			{
				rad = E->trace.basicq[j][2][kk];
				if(rad>(1.0-E->viscosity.zlith))
				{
					E->trace.extraq[j][1][kk] = E->trace.extraq[j][1][kk]+ E->advection.timestep*time_scale;
				}
				else
				{
					E->trace.extraq[j][1][kk] = 0.0;
				}
				
			}
		}
	}
}      
                         
void make_crust(E)
   struct All_variables *E;
{
int i,kk,size1,itracer;
int numOC,totalNumOC;
double *temp_tracer1[13],*temp_theta[13],*temp_phi[13],*temp_rad[13];
double rad,z_ocean_crust;
char output_file[200];
FILE *fpOutput;
int file_ID;
static int been_here=0;
double time_scale=1.288e6;//convert to Ma
FILE *fp;
char tempstring[256];
int element;
int m=1;
float time;

/*
if(E->control.fco2>1e-9)//the fourth index for extraq is used to save fco2
{
	return;
}
*/

if(E->control.melt_flux!=0)
{

	if(been_here==0 && E->control.restart==0 && E->trace.ic_method!=2)
	{
		for(kk=1;kk<=E->trace.ntracers[m];kk++)
		{
			E->trace.extraq[m][4][kk]=0.0;
		}
	}
	been_here=1;

	for (kk=1;kk<=E->trace.ntracers[m];kk++) 
	{
		rad = E->trace.basicq[m][2][kk];
		if(E->trace.extraq[m][2][kk]>0.0)
		{
			if(rad>E->trace.extraq[m][4][kk])
			{
				E->trace.extraq[m][4][kk]=rad;
				E->trace.extraq[m][1][kk] = E->monitor.elapsed_time;
			}
		}
	}
}
else
{
	if(been_here==0)
	{
		for (kk=1;kk<=E->trace.ntracers[m];kk++) 
		{
			E->trace.extraq[m][1][kk]=-1000.0;
		}
		been_here++;
	}
	time=E->monitor.elapsed_time*time_scale;
	for (kk=1;kk<=E->trace.ntracers[m];kk++) 
	{
//for oceanic crust
		rad = E->trace.basicq[m][2][kk];
		if(rad>0.9989)//make crust of 7 km
		{
			E->trace.extraq[m][0][kk]=E->control.make_crust;
			if(time<E->monitor.start_record_time)
			{
				E->trace.extraq[m][1][kk]=-99.0;
			}
			else
			{
				E->trace.extraq[m][1][kk]=time;
			}
		}
//for primordial material
		if((rad-E->sphere.ri)*6371>1000.0 &&E->trace.extraq[m][0][kk]==1)
		{
			if(time<E->monitor.start_record_time)
			{
				E->trace.extraq[m][1][kk]=-99.0;
			}
			else
			{
				if(fabs(E->trace.extraq[m][1][kk])<1e-6)
				{
					E->trace.extraq[m][1][kk]=time;
				}
			}
		}
	}
}


return;
}

void calculate_melting_flux(E)
   struct All_variables *E;
{

int number_of_tracers;
int itracer;
int ipos,intpos;
int ispecie;
int crust_specie;
double z0,x,z,theta,phi,rad;
float Dcrust;
float *aveT,T300;
int i,j,k,kk,Tnode,node,iel,m;
static int been_here=0;
int el,el_above;
float R=6371.0;
float latent_heat;

float P,T,depth;
double Tnd;
float degree_of_dry_melting(float T, float P, float Mcpx, float *Ts);
float katz_wet_melting(float T, float P, float Mcpx, float water);
float kelley_wetmelting(float T, float P, float water, float Mcpx, int fertility);
float depth_pressure();
double get_temperature(struct All_variables *E,
                       int j, int nelem,
                       double theta, double phi, double rad);
double get_element_area();
float F_tracer,F0_tracer,Fout_tracer;
float Tsol,Fout,*velocity;
float *Fout_el_tracer,*CO2_el_tracer,*dFdt_el_tracer,*dCO2dt_el_tracer,*dFdt_el_euler;
float *MFsurf_tracer,*CO2_tracer,*MFsurf_euler,MFtotal_tracer,MFtotal_euler,CO2_total,CO2_global;
int *NT;
int N;
int ielx,iely,ielz,ielxy;
float dt,dz,dr;
float velocity_scale;
float time_scale,Tave;
float *MFave,*MFmax,MFave_total,MFmax_total;
float Fmax,Fave,velo_deepest;
float volume;
double area;
float dx;
float MFglobal_tracer,MFglobal_euler,MFglobal_Fave,MFglobal_Fmax;
float rad1,rad2;
float U_dot_grad_F();
float F[9];

FILE *fp;
char tempstring[256];

parallel_process_sync(E);

latent_heat=E->latent_heating_amount;
if(E->parallel.me==0)
fprintf(stdout,"calculating melt flux\n");


m=E->sphere.caps_per_proc;

if(m!=1)
{
	fprintf(stderr,"caps per proc must be 1\n");
	terminate();
}

time_scale=1.288e12;
velocity_scale=2022.2e5;
dt=time_scale*E->advection.dt_before;

Fout_el_tracer=malloc((E->lmesh.nel+1)*sizeof(float));
CO2_el_tracer=malloc((E->lmesh.nel+1)*sizeof(float));
dFdt_el_tracer=malloc((E->lmesh.nel+1)*sizeof(float));
dCO2dt_el_tracer=malloc((E->lmesh.nel+1)*sizeof(float));
dFdt_el_euler=malloc((E->lmesh.nel+1)*sizeof(float));
velocity=malloc((E->lmesh.nel+1)*sizeof(float));
NT=malloc((E->lmesh.nel+1)*sizeof(int));
MFsurf_tracer=malloc((E->lmesh.elx*E->lmesh.ely+1)*sizeof(float));
CO2_tracer=malloc((E->lmesh.elx*E->lmesh.ely+1)*sizeof(float));
MFsurf_euler=malloc((E->lmesh.elx*E->lmesh.ely+1)*sizeof(float));
MFave=malloc((E->lmesh.elx*E->lmesh.ely+1)*sizeof(float));
MFmax=malloc((E->lmesh.elx*E->lmesh.ely+1)*sizeof(float));

for(iel=1;iel<=E->lmesh.nel;iel++)
{
	Fout_el_tracer[iel]=0.0;
	CO2_el_tracer[iel]=0.0;
	dFdt_el_tracer[iel]=0.0;
	dCO2dt_el_tracer[iel]=0.0;
	dFdt_el_euler[iel]=0.0;
	NT[iel]=0;
	velocity[iel]=0.0;
	for(i=1;i<=8;i++)
	{
		velocity[iel]+=E->sphere.cap[m].V[3][E->ien[m][iel].node[i]]*(float)E->N.ppt[GNPINDEX(i,1)];
	}
	velocity[iel] = velocity[iel]/velocity_scale;
}
for(i=1;i<=E->lmesh.elx*E->lmesh.ely;i++)
{
	MFsurf_tracer[i]=MFsurf_euler[i]=0.0;
	CO2_tracer[i]=0.0;
	MFave[i]=MFmax[i]=0.0;
}

number_of_tracers=E->trace.ntracers[m];


if(been_here==0)
{
	if(E->control.restart==0 && E->trace.ic_method!=2)
	{
		for(itracer=1;itracer<=number_of_tracers;itracer++)
		{
			//ip_F is 2; ip_Fout is 3; fco2 is 4
			E->trace.extraq[m][2][itracer]=0.0;
		}
	}

	if(E->control.restart==0)
	{
		for(itracer=1;itracer<=number_of_tracers;itracer++)
			E->trace.extraq[m][4][itracer]=E->control.fco2;
	}


	E->F0_el=malloc((E->lmesh.nel+1)*sizeof(float));
	E->F_el=malloc((E->lmesh.nel+1)*sizeof(float));
	E->UdotgradF=malloc((E->lmesh.nel+1)*sizeof(float));
	for(i=1;i<=E->lmesh.nel;i++)
	{
		E->UdotgradF[i]=0.0;
		E->F0_el[i]=E->F_el[i]=0.0;
	}


	E->Fnode=malloc((E->lmesh.nno+1)*sizeof(float));
	for(i=1;i<=E->lmesh.nno;i++)
	{
		E->Fnode[i]=0.0;
	}


}



for(itracer=1;itracer<=number_of_tracers;itracer++)
{
	el=E->trace.ielement[m][itracer];
	rad=0.0;

	for(node=1;node<=8;node++)
	{
		rad+=E->sx[m][3][E->ien[m][el].node[node]]*E->N.ppt[GNPINDEX(node,1)];
	}
	rad=E->trace.basicq[m][2][itracer];
	if(rad<0.9529)
	{
		continue;
	}

	theta=E->trace.basicq[m][0][itracer];
	phi=E->trace.basicq[m][1][itracer];

	F0_tracer=E->trace.extraq[m][2][itracer];

	depth=R*(1.0-rad);
	P=depth_pressure(rad);
	Tnd=get_temperature(E,m,el,theta,phi,rad);

	T=E->control.refT*Tnd+E->control.thermal_gradient*depth;

	//T=1873.0;P=8.0;
	if(E->control.melting_model==1)
	{
		F_tracer=degree_of_dry_melting(T,P,E->control.Mcpx,&Tsol);
	}
	else if(E->control.melting_model==2)
	{
		F_tracer=kelley_wetmelting(T,P,E->control.water, E->control.Mcpx,E->control.fertility);
	}
	else if(E->control.melting_model==3)
	{
		F_tracer=katz_wet_melting(T,P,E->control.Mcpx,E->control.water);
	}
	else
	{
		fprintf(stderr,"Wrong melting model\n");
		exit(10);
	}
	if(F_tracer>F0_tracer && F_tracer>0.02)
	{
		E->trace.extraq[m][2][itracer]=F_tracer;
		E->trace.extraq[m][3][itracer]=F_tracer-F0_tracer;
	}
	else
	{
		E->trace.extraq[m][2][itracer]=F0_tracer;//This may not be correct, change F0_tracer to F_tracer may solve the problem
		E->trace.extraq[m][3][itracer]=0.0;
	}
	NT[el]=NT[el]+1;
	Fout_el_tracer[el]=Fout_el_tracer[el]+E->trace.extraq[m][3][itracer];
	if(F_tracer>F0_tracer && F_tracer>0.02)
	{
		CO2_el_tracer[el]=CO2_el_tracer[el]+E->trace.extraq[m][4][itracer]*E->eco[m][el].area*R*R*R*3300.0*1e9;
		E->trace.extraq[m][4][itracer]=0.0;
	}
}



for(i=1;i<=E->lmesh.nel;i++)
{
	E->melt_latent_heat[i]=0.0;
}

for(iely=1;iely<=E->lmesh.ely;iely++)
for(ielx=1;ielx<=E->lmesh.elx;ielx++)
for(ielz=1;ielz<=E->lmesh.elz;ielz++)
{
	el=ielz+(ielx-1)*E->lmesh.elz+(iely-1)*E->lmesh.elx*E->lmesh.elz;
	if(NT[el]==0)
	{
		Fout_el_tracer[el]=0.0;
		CO2_el_tracer[el]=0.0;
	}
	else
	{
		Fout_el_tracer[el]=Fout_el_tracer[el]/NT[el];
		CO2_el_tracer[el]=CO2_el_tracer[el]/NT[el];
	}
//	if(E->parallel.me==0)
//	printf("el=%d %.6e\n",el,Fout_el_tracer[el]);
	if(been_here==0)
	{
		dFdt_el_tracer[el]=0.0;
		dCO2dt_el_tracer[el]=0.0;
	}
	else
	{	
		dFdt_el_tracer[el]=Fout_el_tracer[el]/dt;
		dCO2dt_el_tracer[el]=CO2_el_tracer[el]/dt;
	}
	//E->melt_latent_heat[el]=latent_heat*dFdt_el_tracer[el]*time_scale/(E->data.Cp*E->control.refT);
}

for(j=1;j<=E->lmesh.noy;j++)
for(i=1;i<=E->lmesh.nox;i++)
for(k=1;k<=E->lmesh.noz;k++)
{
	node=k+(i-1)*E->lmesh.noz+(j-1)*E->lmesh.noz*E->lmesh.nox;

	rad=E->sx[m][3][node];

	if(rad<0.9529)
	{
		continue;
	}
	Tnd=E->T[m][node];
	depth=R*(1.0-rad);
	T=E->control.refT*Tnd+E->control.thermal_gradient*depth;
	P=depth_pressure(rad);

	//T=1873.0;P=8.0;
	if(E->control.melting_model==1)
	{
		E->Fnode[node]=degree_of_dry_melting(T,P,E->control.Mcpx,&Tsol);
	}
	else if(E->control.melting_model==2)
	{
		E->Fnode[node]=kelley_wetmelting(T,P,E->control.water, E->control.Mcpx,E->control.fertility);
	}
	else if(E->control.melting_model==3)
	{
		E->Fnode[node]=katz_wet_melting(T,P,E->control.Mcpx,E->control.water);
	}
	else
	{
		fprintf(stderr,"Wrong melting model\n");
		terminate();
	}
}



for(iely=1;iely<=E->lmesh.ely;iely++)
for(ielx=1;ielx<=E->lmesh.elx;ielx++)
for(ielz=1;ielz<=E->lmesh.elz;ielz++)
{
	el=ielz+(ielx-1)*E->lmesh.elz+(iely-1)*E->lmesh.elx*E->lmesh.elz;
	E->F0_el[el]=E->F_el[el];
	E->F_el[el]=0.0;
	for(i=1;i<=8;i++)
	{
		E->F_el[el]+=E->Fnode[E->ien[m][el].node[i]]*0.125;
	}
	if(E->F_el[el]>0.02)
	{
		if(been_here==0)
		{
			dFdt_el_euler[el]=E->UdotgradF[el];
		}
		else
		{
			dFdt_el_euler[el]=(E->F_el[el]-E->F0_el[el])/dt+E->UdotgradF[el];
		}
/*
		if(E->parallel.me==0)
		{
			printf("%.6e %.6e\n",(E->F_el[el]-E->F0_el[el])/dt,fabs(E->UdotgradF[el]));
		}
*/
	}

	for(i=1;i<=8;i++)
	{
		F[i]=E->Fnode[E->ien[m][el].node[i]];
	}
	E->UdotgradF[el]=U_dot_grad_F(E,el,F);
}

MFtotal_tracer=MFtotal_euler=0.0;
MFave_total=MFmax_total=0.0;
CO2_total=0.0;


i=0;
for(iely=1;iely<=E->lmesh.ely;iely++)
for(ielx=1;ielx<=E->lmesh.elx;ielx++)
{
	i++;
	Fmax=Fave=0.0;
	N=0;
	for(ielz=1;ielz<=E->lmesh.elz;ielz++)
	{
		el=ielz+(ielx-1)*E->lmesh.elz+(iely-1)*E->lmesh.elx*E->lmesh.elz;
		volume=E->eco[m][el].area*R*R*R;
		if(dFdt_el_euler[el]>0.0)
		{
			MFsurf_euler[i]=MFsurf_euler[i]+dFdt_el_euler[el]*volume;
			MFtotal_euler=MFtotal_euler+dFdt_el_euler[el]*volume;
		}
		MFsurf_tracer[i]=MFsurf_tracer[i]+dFdt_el_tracer[el]*volume;
		MFtotal_tracer=MFtotal_tracer+dFdt_el_tracer[el]*volume;
		CO2_tracer[i]=CO2_tracer[i]+dCO2dt_el_tracer[el];
		CO2_total+=dCO2dt_el_tracer[el];

		if(E->F_el[el]>0.02)
		{
			N++;
			Fave=Fave+E->F_el[el];
			if(E->F_el[el]>Fmax)
			{
				Fmax=E->F_el[el];
			}
		}
	}
	if(N>0)
	{
		Fave=Fave/N;
	}
	else
	{
		Fave=0.0;
	}

	velo_deepest=0.0;
	area=0.0;
	for(ielz=1;ielz<=E->lmesh.elz;ielz++)
	{
		el=ielz+(ielx-1)*E->lmesh.elz+(iely-1)*E->lmesh.elx*E->lmesh.elz;
		if(E->F_el[el]>0.02 && velocity[el]>0.0)
		{
			velo_deepest=velocity[el];
			area=get_element_area(E,m,el);
			break;
		}
	}
	MFave[i]=velo_deepest*Fave*area*R*R;
	MFmax[i]=velo_deepest*Fmax*area*R*R;
	MFave_total=MFave_total+MFave[i];
	MFmax_total=MFmax_total+MFmax[i];
}

if(E->control.melt_flux==1)
{
	for(el=1;el<=E->lmesh.nel;el++)
	{
		if(dFdt_el_euler[el]>0.0)
		{
			E->melt_latent_heat[el]=latent_heat*dFdt_el_euler[el]*time_scale/(E->data.Cp*E->control.refT);
		}
	}
}
else if(E->control.melt_flux==2)
{
	for(el=1;el<=E->lmesh.nel;el++)
	{
		E->melt_latent_heat[el]=latent_heat*dFdt_el_tracer[el]*time_scale/(E->data.Cp*E->control.refT);
	}
}


MPI_Allreduce(&MFave_total, &MFglobal_Fave, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
MPI_Allreduce(&MFmax_total, &MFglobal_Fmax, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
MPI_Allreduce(&MFtotal_tracer, &MFglobal_tracer, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
MPI_Allreduce(&MFtotal_euler, &MFglobal_euler, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
MPI_Allreduce(&CO2_total, &CO2_global, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);

//printf("%d %f %f %f %f\n",E->parallel.me,MFave_total,MFmax_total,MFtotal_tracer,MFtotal_euler);

//fprintf(stderr,"%07d %.4e %.4e %.4e %.4e %.4e\n",E->advection.timesteps,E->monitor.elapsed_time,MFglobal_tracer,MFglobal_euler,MFglobal_Fave,MFglobal_Fmax);

if(E->parallel.me==0)
{
	fprintf(stderr,"%07d %.4e %.4e %.4e %.4e %.4e\n",E->advection.timesteps,dt,E->monitor.elapsed_time*time_scale,MFglobal_tracer,MFglobal_euler,CO2_global);
	fprintf(E->fp_mf,"%07d %.4e %.4e %.4e %.4e %.4e\n",E->advection.timesteps,dt,E->monitor.elapsed_time*time_scale,MFglobal_tracer,MFglobal_euler,CO2_global);
	fflush(E->fp_mf);
}

//if(E->monitor.solution_cycles % E->control.record_every == 0)
if(E->monitor.solution_cycles % E->MF_save_step == 0)
{
	sprintf(tempstring,"%s/MF/MF.%d.%d",E->control.data_dir,E->parallel.me,E->monitor.solution_cycles);
	if(access(tempstring,F_OK)==-1)
	{
		fp=fopen(tempstring,"w");
		for(i=1;i<=E->lmesh.elx*E->lmesh.ely;i++)
		{
			fprintf(fp,"%.6e %.6e\n",MFsurf_tracer[i],MFsurf_euler[i]);
		}
		fclose(fp);
	}
	else
	{
		fprintf(stderr,"%s already exist\n",tempstring);
	}

/*
	sprintf(tempstring,"%s/CO2/CO2.%d.%d",E->control.data_dir,E->parallel.me,E->monitor.solution_cycles);
	if(access(tempstring,F_OK)==-1)
	{
		fp=fopen(tempstring,"w");
		for(i=1;i<=E->lmesh.elx*E->lmesh.ely;i++)
		{
			fprintf(fp,"%.6e\n",CO2_tracer[i]);
		}
		fclose(fp);
	}
	else
	{
		fprintf(stderr,"%s already exist\n",tempstring);
	}
*/


	sprintf(tempstring,"%s/MF/dFdt.%d.%d",E->control.data_dir,E->parallel.me,E->monitor.solution_cycles);
	if(access(tempstring,F_OK)==-1)
	{
		fp=fopen(tempstring,"w");
		for(iely=1;iely<=E->lmesh.ely;iely++)
		for(ielx=1;ielx<=E->lmesh.elx;ielx++)
		for(ielz=1;ielz<=E->lmesh.elz;ielz++)
		{
			el=ielz+(ielx-1)*E->lmesh.elz+(iely-1)*E->lmesh.elx*E->lmesh.elz;
			if(dFdt_el_euler[el]>0.0 || dFdt_el_tracer[el]>0.0)
			{
//				fprintf(fp,"%d %.6e\n",el,dFdt_el_euler[el]);
				fprintf(fp,"%d %.6e %.6e\n",el,dFdt_el_tracer[el],dFdt_el_euler[el]);
			}
		}
		fclose(fp);
	}
	else
	{
		fprintf(stderr,"%s already exist\n",tempstring);
	}
}

free(Fout_el_tracer);
free(CO2_el_tracer);
free(dCO2dt_el_tracer);
free(NT);
free(dFdt_el_tracer);
free(dFdt_el_euler);
free(velocity);
free(MFsurf_tracer);
free(CO2_tracer);
free(MFsurf_euler);
free(MFave);
free(MFmax);

been_here++;
return;
}

/*
            theta_pred=E->trace.basicq[j][0][kk];
            phi_pred=E->trace.basicq[j][1][kk];
            rad_pred=E->trace.basicq[j][2][kk];
            x_pred=E->trace.basicq[j][3][kk];
            y_pred=E->trace.basicq[j][4][kk];
            z_pred=E->trace.basicq[j][5][kk];

            x0=E->trace.basicq[j][6][kk];
            y0=E->trace.basicq[j][7][kk];
            z0=E->trace.basicq[j][8][kk];

            Vx0=E->trace.basicq[j][9][kk];
            Vy0=E->trace.basicq[j][10][kk];
            Vz0=E->trace.basicq[j][11][kk];
*/


float depth_pressure(depth_citcom)
        double depth_citcom;
{
float density[43];
static float depth[43],pressure[43];
float depth_earth;
float P;
int i;
char tempstring[200],tempstring1[200];
FILE *fpin_prem;
static int been_here=0;

if(fabs(depth_citcom-1.0)<1e-9)
{
        return 0.0;
}


        depth_earth=6371.0*(1.0-depth_citcom);

if(been_here==0)
{
        sprintf(tempstring1,"prem.input");

        if ((fpin_prem=fopen(tempstring1,"r"))==NULL)
        {
        	fprintf(stdout,"ERROR-file does not existdfdfdfd.\n");
		terminate();
        }

        i=1;
        while(fgets(tempstring,200,fpin_prem)!=NULL)
        {
        sscanf(tempstring,"%f %f %f",&depth[i],&density[i],&pressure[i]);
        i=i+1;
        }
        for(i=1;i<42;i++)
        {
        if(depth[i]<depth_earth && depth_earth<depth[i+1])
                {
                P=pressure[i]+((depth_earth-depth[i])/(depth[i+1]-depth[i]))*(pressure[i+1]-pressure[i]);
                break;
                }
        }
        fclose(fpin_prem);
	been_here++;
	return P;
}
else
{
        for(i=1;i<42;i++)
        {
   	     if(depth[i]<depth_earth && depth_earth<depth[i+1])
                {
                	P=pressure[i]+((depth_earth-depth[i])/(depth[i+1]-depth[i]))*(pressure[i+1]-pressure[i]);
	                break;
                }
        }
	return P;
}




}

double get_temperature(struct All_variables *E,
                       int j, int nelem,
                       double theta, double phi, double rad)
{
    int iwedge;
    const int sphere_key = 0;

    double shape[9];
    double temperature,T[7];
    int i;

    void velo_from_element_d();

    full_get_shape_functions(E, shape, nelem, theta, phi, rad);

	iwedge=shape[0];

	if(iwedge==1)
	{
		T[1]=E->T[j][E->ien[j][nelem].node[1]];
		T[2]=E->T[j][E->ien[j][nelem].node[2]];
		T[3]=E->T[j][E->ien[j][nelem].node[3]];
		T[4]=E->T[j][E->ien[j][nelem].node[5]];
		T[5]=E->T[j][E->ien[j][nelem].node[6]];
		T[6]=E->T[j][E->ien[j][nelem].node[7]];
	}
	else if(iwedge==2)
	{
		T[1]=E->T[j][E->ien[j][nelem].node[1]];
		T[2]=E->T[j][E->ien[j][nelem].node[3]];
		T[3]=E->T[j][E->ien[j][nelem].node[4]];
		T[4]=E->T[j][E->ien[j][nelem].node[5]];
		T[5]=E->T[j][E->ien[j][nelem].node[7]];
		T[6]=E->T[j][E->ien[j][nelem].node[8]];
	}

	temperature=0.0;
	for(i=1;i<=6;i++)
	{
		temperature+=T[i]*shape[i];
	}

    return temperature;
}

float degree_of_dry_melting(float T, float P, float Mcpx, float *Ts)
{
  const float T0 = 0.0;
  const float A1 = 1085.7;  // in C
  const float A2 =  132.9;  // in C GPa-1
  const float A3 =   -5.1;  // in C GPa-2
  const float B1 = 1475.0;  // in C
  const float B2 =   80.0;  // in C GPa-1
  const float B3 =   -3.2;  // in C GPa-2
  const float C1 = 1780.0;  // in C
  const float C2 =   45.0;  // in C GPa-1
  const float C3 =   -2.0;  // in C GPa-2
  const float r0 =   0.50;  // in cpx/melt
  const float r1 =   0.08;  // in cpx/melt/GPa
  const float beta1 = 1.50; // exponent
  const float beta2 = 1.50; // exponent
  static int been_here = 0;
  FILE *fp;
  int i;
  float pp,Tsol,Tlhl,Tliq,Tprime,Rcpx,Fcpxout,Tcpxout,F;
  if (been_here++ == 0) {
    fp = fopen("katz_fig1.dat","w");
    for (i=0;i<=160;i++) {
       pp = i/20.;
       Tsol = A1+pp*(A2+pp*A3);
       Tlhl = B1+pp*(B2+pp*B3);
       Tliq = C1+pp*(C2+pp*C3);
       fprintf(fp,"%.02f %.01f %.01f %.01f\n",pp,Tsol,Tlhl,Tliq);
    }
    fclose(fp);
  }

  Tsol = A1+P*(A2+P*A3) + T0; // in K
  Tlhl = B1+P*(B2+P*B3) + T0;
  Tliq = C1+P*(C2+P*C3) + T0;
  *Ts = Tsol;

  Tprime = (T-Tsol)/(Tlhl-Tsol);
  if (T < Tsol) return(0.0);
  if (T > Tliq) return(1.0);
  Rcpx = r0 + r1*P;
if(P>3.5)
{
        Rcpx=r0+r1*3.5;
}
  Fcpxout = Mcpx/Rcpx;

  F = pow(Tprime,beta1);

  if (F > Fcpxout) {
     Tcpxout = pow(Fcpxout,1.0/beta1)*(Tlhl-Tsol)+Tsol;
     Tprime = (T-Tcpxout)/(Tliq-Tcpxout);
     F = Fcpxout + (1.0-Fcpxout)*pow(Tprime,beta2);
  }

  return F;
}

float kelley_wetmelting(float T, float P, float water, float Mcpx, int fertility)
{
        float a,b,c,x,y;
        float water_cal,endF,startF,F,error;
        char ch;
        float term1,term2,term3;
        float Fcpxout,Rcpx;
        float Xh2o,Xh2o_bulk,Xh2o_sat;
        float Tprime;
        float deltaT;
        float F_cal;
        const float T0 = 0.0;
        const float A1 = 1085.7;  // in C
        const float A2 =  132.9;  // in C GPa-1
        const float A3 =   -5.1;  // in C GPa-2
        const float B1 = 1475.0;  // in C
        const float B2 =   80.0;  // in C GPa-1
        const float B3 =   -3.2;  // in C GPa-2
        const float C1 = 1780.0;  // in C
        const float C2 =   45.0;  // in C GPa-1
        const float C3 =   -2.0;  // in C GPa-2
        const float r0 =   0.50;  // in cpx/melt
        const float r1 =   0.08;  // in cpx/melt/GPa
        const float beta1 = 1.50; // exponent
        const float beta2 = 1.50; // exponent
        const float  K=43.0;
        const float  gama=0.75;
        const float  Dh2o=0.01;
        const float  zeta1=12.00;
        const float  zeta2=1.00;
        const float  ramda=0.60;
        float Tsol,Tlhl,Tliq,Tcpxout;

        if(fertility==1)
        {
                a=-5.1404654;
                b = 132.899012;
                c = 1120.66061;
                x = -221.34;
                y = 536.86;
        }
        else
        {
                a = -5.1404654;
                b = 132.899012;
                c = 1159.66061;
                x = -136.88;
                y = 332.01;
        }
        startF=0.0;
        endF=1.0;
        F=0.0;
        do
        {
                term1=Dh2o*(1.0-F)+F;
                term2=(T-(a*P*P+b*P+c)-(x*log(P)+y)*F)/(-60.0);
                if(term2<0.0)
                {
                        startF=F;
                        F=0.5*(startF+endF);
                        error=1.0;
                }
                else
                {
                        term3=pow(term2,1.85);
                        water_cal=term1*term3;
                        error=water_cal-water;
                        if(error<0.0)
                        {
                                startF=F;
                        }
                        else
                        {
                                endF=F;
                        }
                }
                F=0.5*(startF+endF);
        }while(fabs(error)>1e-7 && fabs(startF-endF)>1e-7);

        Rcpx = r0 + r1*P;
        if(P>3.5)
        {
                Rcpx=r0+r1*3.5;
        }
        Fcpxout = Mcpx/Rcpx;

        if (F > Fcpxout)
        {

                Tsol = A1+P*(A2+P*A3); // in oC 
                Tlhl = B1+P*(B2+P*B3);
                Tliq = C1+P*(C2+P*C3);

                Xh2o_bulk=water;

                startF=0.0;
                endF=1.0;
                F=0.0;
                do
                {
                        Xh2o=Xh2o_bulk/(Dh2o+F*(1.0-Dh2o));
                        Xh2o_sat=zeta1*pow(P,ramda)+zeta2*P;
                        if(Xh2o>Xh2o_sat)
                        {
                                Xh2o=Xh2o_sat;
                        }
                        deltaT=K*pow(Xh2o,gama);
                        Tcpxout = pow(Fcpxout,1.0/beta1)*(Tlhl-Tsol)+Tsol-deltaT;
                        Tprime = (T-Tcpxout)/(Tliq-Tcpxout);
                        if(Tprime<0.0)
                        {
                                F_cal=Fcpxout;
                        }
                        else
                        {
                                F_cal = Fcpxout + (1.0-Fcpxout)*pow(Tprime,beta2);
                        }
                        error=F_cal-F;
                        if(error>0)
                        {
                                startF=F;
                        }
                        else
                        {
                                endF=F;
                        }
                        F=0.5*(startF+endF);
                }while(fabs(error)>1e-7 && fabs(startF-endF)>1e-7);
        }        
return F;
}

float katz_wet_melting(float T, float P, float Mcpx, float water)
{
const float T0 = 0.0;
const float A1 = 1085.7;  // in C
const float A2 =  132.9;  // in C GPa-1
const float A3 =   -5.1;  // in C GPa-2
const float B1 = 1475.0;  // in C
const float B2 =   80.0;  // in C GPa-1
const float B3 =   -3.2;  // in C GPa-2
const float C1 = 1780.0;  // in C
const float C2 =   45.0;  // in C GPa-1
const float C3 =   -2.0;  // in C GPa-2
const float r0 =   0.50;  // in cpx/melt
const float r1 =   0.08;  // in cpx/melt/GPa
const float beta1 = 1.50; // exponent
const float beta2 = 1.50; // exponent
const float  K=43.0;
const float  gama=0.75;
const float  Dh2o=0.01;
const float  zeta1=12.00;
const float  zeta2=1.00;
const float  ramda=0.60;
static int been_here = 0;
FILE *fp;
int i;
float pp,Tsol,Tlhl,Tliq,Tprime,Rcpx,Fcpxout,Tcpxout,F;
float Xh2o,Xh2o_bulk,Xh2o_sat;
float startF,endF,error;
float deltaT;
float F_cal;
float Fopx,Fopx_cal;
char ch;
Tsol = A1+P*(A2+P*A3); // in oC 
Tlhl = B1+P*(B2+P*B3);
Tliq = C1+P*(C2+P*C3);

Xh2o_bulk=water;

Rcpx = r0 + r1*P;
if(P>3.5)
{
        Rcpx=r0+r1*3.5;
}
Fcpxout = Mcpx/Rcpx;


startF=0.0;
endF=1.0;
F=0.0;
do
{
        Xh2o=Xh2o_bulk/(Dh2o+F*(1.0-Dh2o));
        Xh2o_sat=zeta1*pow(P,ramda)+zeta2*P;
        if(Xh2o>Xh2o_sat)
        {
                Xh2o=Xh2o_sat;
        }
        deltaT=K*pow(Xh2o,gama);
        F_cal=(T-(Tsol-deltaT))/(Tlhl-Tsol);
        if(F_cal<0.0)
        {
                F_cal=0.0;
        }
        else
        {
                F_cal=pow(F_cal,beta1);
        }
        error=F_cal-F;
        if(error>0)
        {
                startF=F;
        }
        else
        {
                endF=F;
        }
        F=0.5*(startF+endF);
}while(fabs(error)>1e-7 && fabs(startF-endF)>1e-7);

if (F > Fcpxout)
{
        startF=0.0;
        endF=1.0;
        F=0.0;
        do
        {
                Xh2o=Xh2o_bulk/(Dh2o+F*(1.0-Dh2o));
                Xh2o_sat=zeta1*pow(P,ramda)+zeta2*P;
                if(Xh2o>Xh2o_sat)
                {
                        Xh2o=Xh2o_sat;
                }
                deltaT=K*pow(Xh2o,gama);
                Tcpxout = pow(Fcpxout,1.0/beta1)*(Tlhl-Tsol)+Tsol-deltaT;
                Tprime = (T-Tcpxout)/(Tliq-Tcpxout);
                if(Tprime<0.0)
                {
                        F_cal=Fcpxout;
                }
                else
                {
                        F_cal = Fcpxout + (1.0-Fcpxout)*pow(Tprime,beta2);
                }
                error=F_cal-F;
                if(error>0)
                {
                        startF=F;
                }
                else
                {
                        endF=F;
                }
                F=0.5*(startF+endF);
        }while(fabs(error)>1e-7 && fabs(startF-endF)>1e-7);
}
return F;
}

double get_element_area(struct All_variables *E, int m, int iel)
{

double area;
int es,i,j,ii,ia[5],lev;
double aa,y1[4],y2[4],angle[6],xx[4][5],area_sphere_cap();
void get_angle_sphere_cap();
float surf_area;
double temp;

        ia[1]=E->ien[m][iel].node[5];
        ia[2]=E->ien[m][iel].node[6];
        ia[3]=E->ien[m][iel].node[7];
        ia[4]=E->ien[m][iel].node[8];

        for(i=1;i<=4;i++)
        {
                xx[1][i] = E->x[m][1][ia[i]]/E->sx[m][3][ia[1]];
                xx[2][i] = E->x[m][2][ia[i]]/E->sx[m][3][ia[1]];
                xx[3][i] = E->x[m][3][ia[i]]/E->sx[m][3][ia[1]];
        }

        get_angle_sphere_cap(xx,angle);

        area = area_sphere_cap(angle);

return area;
}

float U_dot_grad_F(struct All_variables *E,int e,float *F)
{
float UDF[4][9],rad[9],theta[9],phi[9];
float vtheta,vphi,vrad;
float UdotgradF;
int i,j;
int m=1;
const int dims=E->mesh.nsd;
const int vpts=vpoints[dims];
const int ppts=ppoints[dims];
const int ends=enodes[dims];
const int sphere_key=1;
float VV[4][9],XX[4][9],area;
float velocity_scale=2022.2e5;
float R=6371.0;
void velo_from_element();
float temp1,temp2,temp3;


velo_from_element(E,VV,m,e,sphere_key);

for(j=1;j<=ends;j++)
{
	XX[1][j]=E->sx[m][1][E->ien[m][e].node[j]];
	XX[2][j]=E->sx[m][2][E->ien[m][e].node[j]];
	XX[3][j]=E->sx[m][3][E->ien[m][e].node[j]];
}

vtheta=vphi=vrad=0.0;
for(i=1;i<=8;i++)
{
	vtheta+=VV[1][i]*0.125;
	vphi+=VV[2][i]*0.125;
	vrad+=VV[3][i]*0.125;
}
vtheta/=velocity_scale;
vphi/=velocity_scale;
vrad/=velocity_scale;

for(i=1;i<=vpts;i++)
{
//	vtheta[i]=vphi[i]=vrad[i]=0.0;
	theta[i]=phi[i]=rad[i]=0.0;
	for(j=1;j<=ends;j++)
	{
//		vtheta[i]+=VV[1][j]*E->N.vpt[GNVINDEX(j,i)];
//		vphi[i]+=VV[2][j]*E->N.vpt[GNVINDEX(j,i)];
//		vrad[i]+=VV[3][j]*E->N.vpt[GNVINDEX(j,i)];
		theta[i]+=XX[1][j]*E->N.vpt[GNVINDEX(j,i)];
		phi[i]+=XX[2][j]*E->N.vpt[GNVINDEX(j,i)];
		rad[i]+=XX[3][j]*E->N.vpt[GNVINDEX(j,i)];
	}
}

/*
for(i=1;i<=vpts;i++)
{
	vtheta[i]=vtheta[i]/velocity_scale;
	vphi[i]=vphi[i]/velocity_scale;
	vrad[i]=vrad[i]/velocity_scale;
//	rad[i]=rad[i]*R;
}

*/
/*
for(i=1;i<=vpts;i++)
{
	UDF[i]=0.0;
	for(j=1;j<=ends;j++)
	{
		UDF[i]=UDF[i]+vrad[i]*F[j]*E->gNX[m][e].vpt[GNVXINDEX(2,j,i)]
			+1.0/rad[i]*vtheta[i]*F[j]*E->gNX[m][e].vpt[GNVXINDEX(0,j,i)]
			+1.0/(rad[i]*sin(theta[i]))*vphi[i]*F[j]*E->gNX[m][e].vpt[GNVXINDEX(1,j,i)];
	}
	UDF[i]/=R;
}
*/

for(i=1;i<=vpts;i++)
{
	UDF[1][i]=0.0;
	UDF[2][i]=0.0;
	UDF[3][i]=0.0;
	for(j=1;j<=ends;j++)
	{
		UDF[1][i]+=1.0/rad[i]*F[j]*E->gNX[m][e].vpt[GNVXINDEX(0,j,i)];
		UDF[2][i]+=1.0/(rad[i]*sin(theta[i]))*F[j]*E->gNX[m][e].vpt[GNVXINDEX(1,j,i)];
		UDF[3][i]+=1.0*F[j]*E->gNX[m][e].vpt[GNVXINDEX(2,j,i)];
	}
}

temp1=temp2=temp3=0.0;
for(i=1;i<=vpts;i++)
{
	temp1+=UDF[1][i]*E->gDA[m][e].vpt[i];
	temp2+=UDF[2][i]*E->gDA[m][e].vpt[i];
	temp3+=UDF[3][i]*E->gDA[m][e].vpt[i];
}
temp1/=E->eco[m][e].area;
temp2/=E->eco[m][e].area;
temp3/=E->eco[m][e].area;

//printf("%.6e %.6e %.6e %.6e %.6e %.6e\n",vtheta,temp1,vphi,temp2,vrad,temp3);
//terminate();
UdotgradF=(vtheta*temp1+vphi*temp2+vrad*temp3)/R;

/*
UdotgradF=0.0;
for(i=1;i<=vpts;i++)
{
	UdotgradF+=UDF[i]*E->gDA[m][e].vpt[i];
}

UdotgradF /= E->eco[m][e].area;
*/

return UdotgradF;
}

void reduce_continental_thermal_diffusivity(E)
   struct All_variables *E;
{
int i,j,kk,surface_node;
double rad;
static int been_here=0;
int el;
float tt;
float time_scale=1.288e6;
FILE *fpout;
char tempstring[256];
int cycles;
int num;
int *NT;
int inoz,node;
int m=1;
float depth;

cycles=E->monitor.solution_cycles-1;

for(i=1;i<=E->lmesh.nel;i++)
{
	E->diff[i]*=1.0;//sometime we have depth dependent diff, so use *=1.0 here
	E->cont_viscosity[i]=1.0;
}

for(i=1;i<=E->lmesh.nel;i++)
{
	for(j=1;j<=4;j++)
	{
		node=E->ien[m][i].node[j];
		inoz=node%E->lmesh.noz;
		surface_node=(node-inoz)/E->lmesh.noz+1;
		depth=(1.0-E->sx[m][3][node])*6371;
		if(E->continent[surface_node]==1&&depth<150.0)
		{
			E->diff[i]=E->diff_factor;
			E->cont_viscosity[i]=E->viscosity.continent_viscosity;
			break;
		}
	}
}

/*
	if(cycles % E->control.record_every == 0)
	{
		snprintf(tempstring,255,"%s/diff/diff.%d.%d",E->control.data_dir,E->parallel.me,cycles);
	
		fpout=fopen(tempstring,"wb");
		fwrite(E->diff,sizeof(double),E->lmesh.nel+1,fpout);
		fclose(fpout);
	}
*/
	
        return;
}

void compute_plume_flux(E)
   struct All_variables *E;
{

static int been_here=0;
char tempstring[256];
double time_scale,time;
double plate_velocity;
double *Tave,plumeflux,pf;
double temp,temp1,Tmax,Tbg,Tplume;
int i,j,k,node,num,n;
double get_element_area(struct All_variables *E, int m, int iel);
int m=1;
double *element_area[2];
float *node_area[2];

element_area[m]=malloc((E->lmesh.nel+1)*sizeof(double));
node_area[m]=malloc((E->lmesh.nno+1)*sizeof(float));

for(i=1;i<=E->lmesh.nel;i++)
{
	element_area[m][i]=get_element_area(E,m,i);
}
p_to_nodes(E,element_area,node_area,E->mesh.levmax);

Tave=malloc((E->lmesh.noz+1)*sizeof(double));
return_horiz_ave(E,E->T,Tave,0);

time=E->monitor.elapsed_time;
if(been_here==0)
{
        if(E->parallel.me==0)
        {
                E->control.fpf=malloc((E->lmesh.noz+1)*sizeof(FILE *));
                for(k=1;k<=E->lmesh.noz;k++)
                {
                        sprintf(tempstring,"%s.%d.pf",E->control.data_file,k);
                        E->control.fpf[k]=fopen(tempstring,"a");
                }
        }
        been_here=1;
}

        for(k=1;k<=E->lmesh.noz;k++)
        {
                temp=-10.0;
                temp1=0.0;
                n=0;
                for(i=1;i<=E->lmesh.nsf;i++)
                {
                        node=k+(i-1)*E->lmesh.noz;
                        if(E->T[m][node]>Tave[k])
                        {
                                n++;
                                temp1+=E->T[m][node];
                        }
			if(E->T[m][node]>temp)
	                        temp=E->T[m][node];
                }
		//MPI_Allreduce(&Tmax, &temp,1,MPI_DOUBLE,MPI_MAX,E->parallel.world);
		MPI_Allreduce(&temp, &Tmax,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);

                MPI_Allreduce(&temp1, &Tbg, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
                MPI_Allreduce(&n, &num, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
                Tbg/=num;

                Tplume=Tbg+E->frac*(Tmax-Tbg);

                plumeflux=0.0;
                for(i=1;i<=E->lmesh.nsf;i++)
                {
                        node=k+(i-1)*E->lmesh.noz;
                        if(E->T[m][node]>Tplume && E->sphere.cap[m].V[3][node]>0.0)
                        {
                                plumeflux+=E->sphere.cap[m].V[3][node]*(E->T[m][node]-Tave[k])*node_area[m][node];
                        }
                }
                MPI_Allreduce(&plumeflux, &pf, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
                if(E->parallel.me==0)
                {
                        fprintf(E->control.fpf[k],"%d %.6e %.6e\n",E->monitor.solution_cycles,time,pf);
                        fflush(E->control.fpf[k]);
                }
        }

free(Tave);
free(element_area[m]);
free(node_area[m]);


return;
}

void adjust_buoyancy_ratio(E,icomp)
	struct All_variables *E;
	int icomp;
{
float global_area,global_pile_area;
float area,area_pile;
int e,i;
float CMB_area;

area=0.0;
area_pile=0.0;
for (e=1; e<=E->lmesh.nel; e=e+E->lmesh.elz)
{
	area+=E->eco[1][e].area/E->eco[1][e].size[3];
	if(E->composition.comp_el[1][icomp][e]>0.3)
	{
		area_pile+=E->eco[1][e].area/E->eco[1][e].size[3];
	}
}
MPI_Allreduce(&area, &global_area, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
MPI_Allreduce(&area_pile, &global_pile_area, 1, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);

if(E->parallel.me==0)
{
	fprintf(stderr,"pile area = %f of CMB time= %f Ma\n",global_pile_area/global_area,E->monitor.runtime-E->monitor.elapsed_time*1.288e6);
	fprintf(E->fp,"pile area = %f of CMB time= %f Ma\n",global_pile_area/global_area,E->monitor.runtime-E->monitor.elapsed_time*1.288e6);
}

if(global_pile_area/global_area<0.3)
{
	E->composition.buoyancy_ratio[icomp]+=0.01;
	if(E->parallel.me==0)
	{
		fprintf(stderr,"increase buoyancy number for %d tracer to %.2f\n",icomp+1,E->composition.buoyancy_ratio[icomp]);
		fprintf(E->fp,"increase buoyancy number for %d tracer to %.2f\n",icomp+1,E->composition.buoyancy_ratio[icomp]);
	}
}
else if(global_pile_area/global_area>0.4 && E->monitor.elapsed_time*1.288e6>50.0)
{
	E->composition.buoyancy_ratio[icomp]-=0.01;
	if(E->parallel.me==0)
	{
		fprintf(stderr,"decrease buoyancy number for %d tracer to %.2f\n",icomp+1,E->composition.buoyancy_ratio[icomp]);
		fprintf(E->fp,"decrease buoyancy number for %d tracer to %.2f\n",icomp+1,E->composition.buoyancy_ratio[icomp]);
	}
}

return;
}

void add_layered_composition(E)
	struct All_variables *E;
{
int j, kk, number_of_tracers;
int i;
double flavor;
double theta,phi,rad;
double x0,y0,z0,x1,y1,z1;
double distance;

      for (j=1;j<=E->sphere.caps_per_proc;j++) {

	number_of_tracers = E->trace.ntracers[j];
	for (kk=1;kk<=number_of_tracers;kk++) {
	  rad = E->trace.basicq[j][2][kk];

          flavor = E->trace.nflavors - 1;
          for (i=0; i<E->trace.nflavors-1; i++) {
              if (rad > E->trace.z_interface[i]) {
                  flavor = i;
                  break;
              }
          }
          E->trace.extraq[j][0][kk] = flavor;
         
          E->trace.extraq[j][1][kk] = 0.0;
	}
      }
return;
}

void add_continents(E)
	struct All_variables *E;
{
int j, kk, number_of_tracers;
int i;
double flavor;
double theta,phi,rad;
double x0,y0,z0,x1,y1,z1;
double distance;
	for (j=1;j<=E->sphere.caps_per_proc;j++) 
	{
		number_of_tracers = E->trace.ntracers[j];
		for (kk=1;kk<=number_of_tracers;kk++) 
		{
			theta = E->trace.basicq[j][0][kk];
			phi = E->trace.basicq[j][1][kk];
			rad = E->trace.basicq[j][2][kk];
          		flavor=E->trace.extraq[j][0][kk];
			if(rad<0.96861)
			{
				continue;
			}
            		sphere_to_cart(E,theta,phi,rad,&x1,&y1,&z1);
			for (i=0; i<E->trace.number_of_continents; i++) 
			{
            			sphere_to_cart(E,E->trace.lat_of_continents[i],E->trace.lon_of_continents[i],rad,&x0,&y0,&z0);
				distance=sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)+(z1-z0)*(z1-z0));			
				distance=distance/rad;
				if(distance<E->trace.radius_of_continents[i])	
				{
					flavor=E->trace.continent_flavor;
					break;
				}
			}
			E->trace.extraq[j][0][kk] = flavor;
			E->trace.extraq[j][1][kk] = 0.0;
		}
	}
return;
}
